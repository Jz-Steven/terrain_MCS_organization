fig, axes = plt.subplots(nrows=2, ncols=3, 
                         figsize=(15, 9), dpi=300,
                         subplot_kw={'projection': ccrs.PlateCarree()})

axes_flat = axes.flatten()

labels = ['(a)', '(b)', '(c)', '(d)', '(e)', '(f)']

mesh = None 

for i, target_str in enumerate(target_moments):
    ax = axes_flat[i]
    label_idx = labels[i]
     
    f_path = find_file_by_time(target_str, base_dir)
    
    if f_path is None:
        print(f"[{i+1}/6] 未找到文件: {target_str}")
        ax.text(0.5, 0.5, "Data Missing", ha='center', transform=ax.transAxes)
        continue
        
    print(f"[{i+1}/6] 正在绘制: {target_str}")
    

    try:
        f = CinradReader(f_path)
        rl = list(f.iter_tilt(230, 'REF'))
        cr = quick_cr(rl)
           
        lon_grid, lat_grid = get_latlon_grid(cr, site_lon, site_lat)
        
        mesh = ax.contourf(lon_grid, lat_grid, cr['CR'], 
                           cmap=cmap_mdbz, norm=norm_mdbz, levels =levels_mdbz,
                           transform=ccrs.PlateCarree(),zorder = 3
                            )
               
        ax.set_extent(extent, crs=ccrs.PlateCarree())
        
        provinces = cfeature.ShapelyFeature(
            Reader(shp_path).geometries(),
            ccrs.PlateCarree(), 
            edgecolor='black', facecolor='none', linewidth=0.8
        )
        ax.add_feature(provinces, zorder = 5)
        
        ax.scatter(site_lon, site_lat, color='b', marker=r'$\bigoplus$', s=100, zorder=5)

        time_display = target_str[4:] 
        

        ax.text(0.03, 0.90, f"{label_idx} {time_display} UTC", 
                transform=ax.transAxes, 
                fontsize=25, fontweight='bold', color='black',
                bbox=dict(facecolor='white', edgecolor='none', alpha=0.8, pad=3))

        gl = ax.gridlines(draw_labels=True, linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
        gl.xlocator = MultipleLocator(0.5)  
        gl.ylocator = MultipleLocator(0.5)  
        gl.top_labels = False
        gl.right_labels = False
        
        if i % 3 != 0: 
            gl.left_labels = False
        if i < 3: 
            gl.bottom_labels = False
            
        gl.xformatter = LONGITUDE_FORMATTER
        gl.yformatter = LATITUDE_FORMATTER
        gl.xlabel_style = {'size': 20}
        gl.ylabel_style = {'size': 20}
        
        for spine in ax.spines.values():
            spine.set_edgecolor('black')  
            spine.set_linewidth(1.5)      

    except Exception as e:
        print(f"  绘图出错: {e}")


plt.subplots_adjust(bottom=0.15, wspace=0.05, hspace=0.02)
point1_lon, point1_lat = 117.45, 23.92  
point2_lon, point2_lat = 118.75, 24.92 

axes_flat[4].plot([point1_lon, point2_lon], [point1_lat, point2_lat], 
                color='k', linewidth=3, 
                transform=ccrs.PlateCarree(),  
                alpha=0.9,zorder=10)

cbar_ax = fig.add_axes([0.2, 0.04, 0.6, 0.025]) 
cbar = fig.colorbar(mesh, cax=cbar_ax, orientation='horizontal')

cbar.ax.set_title('Composite Reflectivity [dBZ]', fontsize=18)
cbar.set_ticks(levels_mdbz[1:]) 
cbar.ax.tick_params(axis='x', labelsize=18, labelcolor='k', direction='out', length=5, width=1)
for spine in cbar.ax.spines.values():
    spine.set_edgecolor('black') 
    spine.set_linewidth(1)      
    
output_path = '/'
plt.savefig(output_path, bbox_inches='tight')
plt.show()



 
fig, ax = plt.subplots(figsize=(8, 6), dpi=300)
    
X, Y = np.meshgrid(dist_axis, time_nums[20:101])
mesh = ax.contourf(X, Y, matrix[20:101], cmap=cmap_mdbz, norm=norm_mdbz,levels = levels_mdbz)

time_series = pd.Series(times_cst)

hours = time_series.dt.floor('h')
    

unique_hour_indices = hours.drop_duplicates(keep='first').index
    
ticks_to_show = np.array(time_nums)[unique_hour_indices]


ax.set_yticks(ticks_to_show[2:11])
    
ax.yaxis.set_major_formatter(mdates.DateFormatter('%H00'))
    

ax.grid(True, axis='x', linestyle='--', color='dimgrey', linewidth=1.5, alpha=0.8)
ax.set_xlabel("Distance (km)", fontsize=23,labelpad = 10)
ax.set_ylabel("Time on May 7 (UTC)", fontsize=23,labelpad = 15)
ax.set_xticks([0, 50, 100,150])
ax.tick_params(axis='both', labelsize=23, direction='out', length=5, width=1.5, pad=1)

ax.text(0.01, -0.08, 'SW', fontsize=18, va='top', ha='left', transform=ax.transAxes)
ax.text(0.93, -0.08, 'NE', fontsize=18, va='top', ha='left', transform=ax.transAxes)
for spine in ax.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)

ax.text(0.03, 0.97, '(g) OBS', transform=ax.transAxes,
              fontsize=28, color='black', ha='left', va='top', fontweight= 'bold',
              bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', boxstyle='round,pad=0.3'))

plt.tight_layout()
plt.show()
fig.savefig('/')
