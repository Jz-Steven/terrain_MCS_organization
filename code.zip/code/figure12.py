fig, axs = plt.subplots(2, 1, figsize=(7, 12), sharex=True)  # 2行1列，子图共享x轴
plt.subplots_adjust(hspace=0.05)  # 图与图之间的间距

time_idx = 12
selected = [23.3, 23.5, 23.7, 23.9, 24.1]
actual = to_np(lat_plot)
indices = [np.abs(actual - sel_lat).argmin() for sel_lat in selected]
chosen = actual[indices]
target_lat = 23.85
target_idx = np.abs(actual - target_lat).argmin()
target_val = actual[target_idx]

ax1 = axs[0]

q_ctrl_plot = q_west_east_mean_ctrl_vertical.isel(time=time_idx)
q_diff_plot = q_west_east_mean_diff_vertical.isel(time=time_idx)

ht_time = ht_west_east_mean_ctrl.isel(time=time_idx)
lats_2d, z_2d = np.meshgrid(lat_plot, ht_time[:, 0])

cf = ax1.contourf(lats_2d, z_2d, to_np(q_diff_plot),
                  cmap=cmap_q, levels=levels_q, norm=norm_q, extend='both')


q_lines = ax1.contour(lats_2d, z_2d, to_np(q_ctrl_plot), levels=np.arange(11, 20, 1),
                      linewidths=1.3, colors='magenta', linestyles='-', alpha=0.8)
ax1.clabel(q_lines, fontsize=12, colors='magenta')

ax1.fill_between(lats_2d[0], 0, to_np(ter_filled), facecolor="saddlebrown", zorder=10)
ax1.plot(lats_2d[0], to_np(ter_filled_sm), color="w", linewidth=2, linestyle="--", zorder=12)

ax1.set_xticks(chosen)
ax1.set_xticklabels([f"{lat:.1f}" for lat in chosen], fontsize=22)

ax1.set_yticks([0, 1, 2, 3, 4])
ax1.set_ylim(0.02, 3.1)
ax1.yaxis.set_minor_locator(tick.MultipleLocator(0.2))
ax1.yaxis.set_major_formatter(tick.FormatStrFormatter("%d"))
ax1.tick_params(axis='both', labelsize=22, width=1.5, length=5, direction='out')
ax1.tick_params(axis='y', which='minor', length=3)
ax1.set_ylabel("Height (km)", fontsize=25, labelpad=55)

for spine in ax1.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)

ax1.text(0.03, 0.97, '(a) Q @ 0200 UTC', transform=ax1.transAxes,
         fontsize=30, ha='left', va='top', fontweight='bold',
         bbox=dict(facecolor='white', alpha=0.8, edgecolor='none', boxstyle='round,pad=0.3'))

ax2 = axs[1]
data = q_integral_west_east_mean_diff[6:37]
label_b = '(b) IWV 700'

qf = ax2.contourf(
    to_np(lat_plot),
    Time_correct[6:37],
    to_np(data),
    levels=levels_q,
    cmap=cmap_q,
    norm=norm_q,
    extend='both'
)

ax2.set_xlabel("Latitude(°N)", fontsize=25)
ax2.set_ylabel("Time on May 7(UTC)", fontsize=25, labelpad=15)

ax2.set_xticks(chosen)

labels = []
for val in chosen:
    if abs(val - target_val) < 0.01:
        labels.append(f"$\\bf{{{val:.2f}}}$")
    else:
        labels.append(f"{val:.1f}")
ax2.set_xticklabels(labels, fontsize=22)
for label_obj in ax2.get_xticklabels():
    if label_obj.get_text().replace('$\\bf{', '').replace('}$', '') == f"{target_val:.2f}":
        label_obj.set_color('crimson')

ax2.set_yticks(Time_correct[6:37][::6])
ax2.yaxis.set_major_formatter(mdates.DateFormatter('%H%M'))
ax2.tick_params(axis='both', labelsize=22, width=1.5, length=5, direction='out')
ax2.grid(True, linestyle='--', color='dimgrey', linewidth=1.3)


for spine in ax2.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)


cbar_ax = fig.add_axes([0.98, 0.5, 0.04, 0.38]) 
cbar = fig.colorbar(cf, cax=cbar_ax, orientation='vertical', extend='both')
cbar.set_ticks([-2, -1, 0, 1, 2, 3])
cbar.ax.text(-1.35, 0.5, 'Q Difference [g·kg$^{-1}$]', fontsize=23,
                  va='center', ha='left', rotation=90, transform=cbar.ax.transAxes)

cbar.ax.tick_params(labelsize=20, direction='out', length=5, width=1)
for spine in cbar.ax.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1)

cbar_ax = fig.add_axes([0.98, 0.1, 0.04, 0.38]) 
cbar = fig.colorbar(cf, cax=cbar_ax, orientation='vertical', extend='both')
cbar.set_ticks([-2, -1, 0, 1, 2, 3])
cbar.ax.text(-1.35, 0.5, 'IWV Difference [kg·m$^{-2}$]', fontsize=23,
            va='center', ha='left', rotation=90, transform=cbar.ax.transAxes)
cbar.ax.tick_params(labelsize=20, direction='out', length=5, width=1)
for spine in cbar.ax.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1)


ax2.text(0.03, 0.97, label_b, transform=ax2.transAxes,
         fontsize=30, ha='left', va='top', fontweight='bold',
         bbox=dict(facecolor='white', alpha=0.8, edgecolor='none', boxstyle='round,pad=0.3'))

ax1.text(0.5, 1.2, 'CTRL − NO_SM', transform=ax1.transAxes,
         fontsize=35, ha='center', va='top', fontweight='bold')

plt.savefig('/', dpi=600, bbox_inches="tight")
plt.show()
