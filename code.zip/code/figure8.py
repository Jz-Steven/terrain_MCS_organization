def plot_rain_distribution(ax, lons, lats, mdbz_data, 
                           levels, cmap, norm, provinces, wrf_proj, title, is_left=False, is_bottom=False):

    im = ax.contourf(
        to_np(lons), to_np(lats), to_np(mdbz_data),
        levels=levels, cmap=cmap, norm=norm,
        transform=ccrs.PlateCarree(), alpha=1
    )

    ax.add_feature(provinces, edgecolor='grey', linewidth=1.8)
    ax.set_extent([116.3,119,23.1,25.3], crs=ccrs.PlateCarree())

    gl = ax.gridlines(color="grey", linestyle="dotted", draw_labels=True, x_inline=False, y_inline=False)
    gl.top_labels = False
    gl.right_labels = False
    gl.rotate_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    gl.xlocator = FixedLocator(np.arange(115, 120, 0.5)) 
    gl.ylocator = MultipleLocator(0.5) 
    gl.xlabel_style = {'size': 25}
    gl.ylabel_style = {'size': 25}
    if not is_left:
        gl.left_labels = False 
    else:
        gl.left_labels = True  
        
    if not is_bottom:
        gl.bottom_labels = False 
    else:
        gl.bottom_labels = True   
        
    ax.tick_params(axis='both', labelsize=25, labelcolor='k', direction='out', length=5, width=1.5)

    for spine in ax.spines.values():
            spine.set_edgecolor('black') 
            spine.set_linewidth(1.5)    
 
    ax.text(0.03, 0.965, title, fontsize=30, fontweight = 'bold', transform=ax.transAxes, va='top', ha='left',
            bbox=dict(facecolor='white', alpha=0.7, edgecolor='white', boxstyle='round,pad=0.3'))
    
    return im


def main():
  
    shp_path = '/public/home/acbb7vqhjq/zji/salem_shp/China_shp_lqy/'
    provinces = cfeature.ShapelyFeature(
        Reader(shp_path + 'province.shp').geometries(),
        ccrs.PlateCarree(), edgecolor='k', facecolor='none'
    )

    mdbz_data_1 = mdbz_sm[0]
    mdbz_data_2 = mdbz_sm[12]
    mdbz_data_3 = mdbz_sm[18]
    mdbz_data_4 = mdbz_sm[24]
    mdbz_data_5 = mdbz_sm[36]
    mdbz_data_6 = mdbz_sm[48]
    
    mdbz_data_7 = mdbz_meso[0]
    mdbz_data_8 = mdbz_meso[12]
    mdbz_data_9 = mdbz_meso[18]
    mdbz_data_10 = mdbz_meso[24]
    mdbz_data_11 = mdbz_meso[36]
    mdbz_data_12 = mdbz_meso[48]

    fig, axes = plt.subplots(4, 3, figsize=(18, 21), 
                             subplot_kw={'projection': wrf_proj}, gridspec_kw={'hspace': 0.04, 'wspace': 0.002},
                             sharex='col')
    

    im1 = plot_rain_distribution(
        axes[0,0], lons, lats, mdbz_data_1, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(a1) 0000 UTC", is_left=True, is_bottom=False,
    )
    im2 = plot_rain_distribution(
        axes[0,1], lons, lats, mdbz_data_2, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(b1) 0200 UTC", is_left=False, is_bottom=False,
    )  
    im3 = plot_rain_distribution(
        axes[0,2], lons, lats, mdbz_data_3, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(c1) 0300 UTC", is_left=False, is_bottom=False,
    )
    im4 = plot_rain_distribution(
        axes[1,0], lons, lats, mdbz_data_4, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(d1) 0400 UTC", is_left=True, is_bottom=False,
    )
    im5 = plot_rain_distribution(
        axes[1,1], lons, lats, mdbz_data_5, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(e1) 0600 UTC", is_left=False, is_bottom=False,
    )  
    im6 = plot_rain_distribution(
        axes[1,2], lons, lats, mdbz_data_6, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(f1) 0800 UTC", is_left=False, is_bottom=False,
    )
    im7 = plot_rain_distribution(
        axes[2,0], lons, lats, mdbz_data_7, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(a2) 0000 UTC", is_left=True, is_bottom=False,
    )
    im8 = plot_rain_distribution(
        axes[2,1], lons, lats, mdbz_data_8, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(b2) 0200 UTC", is_left=False, is_bottom=False,
    )  
    im9 = plot_rain_distribution(
        axes[2,2], lons, lats, mdbz_data_9, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(c2) 0300 UTC", is_left=False, is_bottom=False,
    )
    im10 = plot_rain_distribution(
        axes[3,0], lons, lats, mdbz_data_10, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(d2) 0400 UTC", is_left=True, is_bottom=True,
    )
    im11 = plot_rain_distribution(
        axes[3,1], lons, lats, mdbz_data_11, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(e2) 0600 UTC", is_left=False, is_bottom=True,
    )  
    im12 = plot_rain_distribution(
        axes[3,2], lons, lats, mdbz_data_12, 
        levels_mdbz, cmap_mdbz, norm_mdbz, provinces, wrf_proj, "(f2) 0800 UTC", is_left=False, is_bottom=True,
    )
    
    lon_min, lon_max = 116.8, 117.72
    lat_min, lat_max = 23.75, 24.35
    rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
    rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]

    lon_min, lon_max = 117.3, 117.4
    lat_min, lat_max = 23.2, 24.3
    rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
    rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
    axes[0,2].plot(rect_lons, rect_lats, color='k', linewidth=2, transform=ccrs.PlateCarree(), linestyle='-', alpha = 0.9)
  
    lon_min, lon_max = 117.33, 117.43
    lat_min, lat_max = 23.0, 24.1
    rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
    rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
 
    point1_lon, point1_lat = 116.7, 23.52  
    point2_lon, point2_lat = 118.05, 24.5  

    axes[1,1].plot([point1_lon, point2_lon], [point1_lat, point2_lat], color='k', linewidth=3,transform=ccrs.PlateCarree(), alpha = 0.9)
    axes[3,1].plot([point1_lon, point2_lon], [point1_lat, point2_lat], color='k', linewidth=3,transform=ccrs.PlateCarree(), alpha = 0.9)

    l = 0.21
    b = 0.03
    w = 0.6
    h = 0.02
    rect = [l, b, w, h]
    cbar_ax = fig.add_axes(rect)
    cbar = fig.colorbar(im1, cax=cbar_ax, orientation='horizontal')
    cbar.ax.set_title('Maximum Reflectivity [dBZ]', fontsize=25, pad=8)
    cbar.ax.tick_params(labelsize=25)
    cbar.set_ticks([5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70])
    cbar.ax.tick_params(axis='x', labelsize=25, labelcolor='k', direction='out', length=5, width=1)
    for spine in cbar.ax.spines.values():
                spine.set_edgecolor('black') 
                spine.set_linewidth(1)    

    fig.text(0.04, 0.7, 'NO_SM', va='center', rotation='vertical', fontsize=40, fontweight = 'bold')
    fig.text(0.04, 0.3, 'NO_MESO', va='center', rotation='vertical', fontsize=40, fontweight = 'bold')


    plt.savefig('/', dpi=300, bbox_inches="tight")
    plt.show()

# 执行主程序
main()