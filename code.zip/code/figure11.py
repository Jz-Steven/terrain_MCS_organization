def plot_bwd(ax, lons, lats, bwd_data, mdbz, colors, colors_2, mean_value,BWD_u,BWD_v,
             levels, cmap, norm, provinces, wrf_proj, title, is_left=False, is_bottom=False):
    
 
    im = ax.contourf(
        to_np(lons), to_np(lats), to_np(bwd_data),
        levels=levels, cmap=cmap, norm=norm, 
        transform=ccrs.PlateCarree(), alpha=1
    )

    mdbz_c = ax.contour(
    to_np(lons),
    to_np(lats),
    to_np(mdbz),
    levels=[40],
    colors=colors,
    linestyles=['solid'],
    linewidths=1.8,
    transform=ccrs.PlateCarree()
    )

    n = 30
    ax.barbs(to_np(lons[::n,::n]), to_np(lats[::n,::n]),
             to_np(BWD_u[6][::n,::n]), to_np(BWD_v[6][::n,::n]),
             linewidth=1,flagcolor='k',length=6, pivot='tip', 
             barb_increments=dict(half=2, full=4, flag=20), transform=ccrs.PlateCarree())

    lon_min, lon_max = 116.7, 117.7
    lat_min, lat_max = 23.5, 24.4
    rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
    rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
    ax.text(0.65, 0.37, f"{mean_value.values:.2f}", transform=ax.transAxes, fontsize=25, #fontweight='bold', 
             va='top', ha='left', color=colors_2)

    
    ax.plot(rotated_lons, rotated_lats, color=colors_2, linewidth=3, transform=ccrs.PlateCarree(), linestyle='--')

    ax.add_feature(provinces, edgecolor='dimgrey', linewidth=1.8)

    ax.set_extent([116.3,119,23.1,25.3], crs=ccrs.PlateCarree())
    gl = ax.gridlines(color="black", linestyle="dotted", draw_labels=True, x_inline=False, y_inline=False)
    gl.top_labels = False
    gl.right_labels = False
    gl.rotate_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    gl.xlocator = FixedLocator(np.arange(115, 120, 1))  
    gl.ylocator = MultipleLocator(1)  
    gl.xlabel_style = {'size': 25}
    gl.ylabel_style = {'size': 25}
    if not is_left:
        gl.left_labels = False  
    else:
        gl.left_labels = True 
        
    if not is_bottom:
        gl.bottom_labels = False 
        gl.bottom_labels = True   
        
    ax.tick_params(axis='both', labelsize=25, labelcolor='k', direction='out', length=5, width=1.5)

    for spine in ax.spines.values():
            spine.set_edgecolor('black')  
            spine.set_linewidth(1.5)     
    # 添加标题或标识
    ax.text(0.035, 0.96, title, fontsize=28, fontweight = 'bold', transform=ax.transAxes, va='top', ha='left',
            bbox=dict(facecolor='white', alpha=0.7, edgecolor='white', boxstyle='round,pad=0.3'))
    
    return im

# 主程序
def main():
    # 假设以下变量已定义
    shp_path = '/public/home/acbb7vqhjq/zji/salem_shp/China_shp_lqy/'
    provinces = cfeature.ShapelyFeature(
        Reader(shp_path + 'province.shp').geometries(),
        ccrs.PlateCarree(), edgecolor='k', facecolor='none'
    )
    
 
    bwd_data_1 = BWD_t[6]
    bwd_data_2 = BWD_t_sm[6]
    bwd_data_3 = BWD_n[6]
    bwd_data_4 = BWD_n_sm[6]


    fig, axes = plt.subplots(2, 2, figsize=(10, 9), 
                             subplot_kw={'projection': wrf_proj}, gridspec_kw={'hspace': 0.03, 'wspace': 0.02})
    

    im1 = plot_bwd(
        axes[0,0], lons, lats, bwd_data_1, mdbz,'darkorange','magenta', mean_BWD_t[6], BWD_u, BWD_v,
        levels_bwd, cmap_bwd, norm_bwd, provinces, wrf_proj, "(a)", is_left=True, is_bottom=False,
    )

    im2 = plot_bwd(
        axes[0,1], lons, lats, bwd_data_2,  mdbz_sm,'darkorange','magenta',mean_BWD_t_sm[6], BWD_u_sm, BWD_v_sm,
        levels_bwd, cmap_bwd, norm_bwd, provinces, wrf_proj, "(b)", is_left=False, is_bottom=False,
    )  
 
    im3 = plot_bwd(
        axes[1,0], lons, lats, bwd_data_3, mdbz, 'darkorange','magenta',mean_BWD_n[6], BWD_u, BWD_v,
        levels_bwdn, cmap_bwdn, norm_bwdn, provinces, wrf_proj, "(c)", is_left=True, is_bottom=True,
    )

    im5 = plot_bwd(
        axes[1,1], lons, lats, bwd_data_4, mdbz_sm, 'darkorange','magenta',mean_BWD_n_sm[6], BWD_u_sm, BWD_v_sm,
        levels_bwdn, cmap_bwdn, norm_bwdn, provinces, wrf_proj, "(d)", is_left=False, is_bottom=True,
    )
    

    point1_lon, point1_lat = 115.6, 22.2  
    point2_lon, point2_lat = 116.6, 22.9  
 
    point1_lon, point1_lat = 115.6, 22.2  # 第一个点
    point2_lon, point2_lat = 116.6, 22.2  # 第二个点
 
    axes[0,0].plot([point1_lon, point2_lon], [point1_lat, point2_lat], color='magenta', linewidth=1.5,transform=ccrs.PlateCarree())
    
    fig.text(-0.01, 0.7, '0-6 km BWD along', va='center', rotation='vertical', fontsize=25)
    fig.text(-0.01, 0.3, '0-6 km BWD normal', va='center', rotation='vertical', fontsize=25)
    fig.text(0.28, 0.9, 'CTRL', va='center', rotation='horizontal', fontsize=25, fontweight = 'bold')
    fig.text(0.65, 0.9, 'NO_SM', va='center', rotation='horizontal', fontsize=25, fontweight = 'bold')

    cbar_ax1 = fig.add_axes([0.92, 0.52, 0.015, 0.34])
    cbar1 = fig.colorbar(im1, cax=cbar_ax1, orientation='vertical')
    cbar1.ax.text(0.81, 1.04, 'm·s$^{-1}$', fontsize=15, va='center', ha='center', transform=cbar1.ax.transAxes)
    cbar1.set_ticks([6,8,10,12,14,16,18,20,22])
    cbar1.ax.tick_params(axis='y', labelsize=20, labelcolor='k', direction='out', length=5, width=1)
    for spine in cbar1.ax.spines.values():
        spine.set_edgecolor('black')
        spine.set_linewidth(1)

    cbar_ax2 = fig.add_axes([0.92, 0.12, 0.015, 0.34])
    cbar2 = fig.colorbar(im3, cax=cbar_ax2, orientation='vertical')
    cbar2.ax.text(0.81, 1.04, 'm·s$^{-1}$', fontsize=15, va='center', ha='center', transform=cbar2.ax.transAxes)
    cbar2.set_ticks([-12,-8,-4,0,4,8,12])
    cbar2.ax.tick_params(axis='y', labelsize=20, labelcolor='k', direction='out', length=5, width=1)
    for spine in cbar2.ax.spines.values():
        spine.set_edgecolor('black')
        spine.set_linewidth(1)


    plt.savefig('/', dpi=600, bbox_inches="tight")
    plt.show()

# 执行主程序
main()




fig, (ax1_bottom, ax1_top) = plt.subplots(2, 1, figsize=(11, 8), sharex=True)

time = pd.to_datetime(mean_BWD_t.Time.values)

color_ctrl_along = (231/255,55/255,60/255)
color_nosm_along = (119/255,206/255,244/255)
ax1_top.plot(time, mean_BWD_t_3, label="CTRL (along)",
         color=color_ctrl_along, linewidth=3, linestyle='-', marker='s', markersize=8)
ax1_top.plot(time, mean_BWD_t_sm_3, label="NO_SM (along)",
         color=color_nosm_along, linewidth=3, linestyle='-', marker='s', markersize=8)

ax1_top.set_ylabel("0–3 km BWD along", fontsize=25, labelpad=22, color='black')
ax1_top.tick_params(axis='y', labelsize=22, width=2, direction='out')

ax2_top = ax1_top.twinx()
color_ctrl_normal = (255/255,205/255,49/255)
color_nosm_normal = (78/255,197/255,171/255)
ax2_top.plot(time, mean_BWD_n_3, label="CTRL (normal)",
         color=color_ctrl_normal, linewidth=3, linestyle='-.')
ax2_top.plot(time, mean_BWD_n_sm_3, label="NO_SM (normal)",
         color=color_nosm_normal, linewidth=3, linestyle='-.')

ax2_top.set_ylabel("0–3 km BWD normal", fontsize=25, labelpad=18, color='black')
ax2_top.tick_params(axis='y', labelsize=22, width=2, direction='out')


left_min_top = 5
left_max_top = 10
ax1_top.set_ylim(left_min_top, left_max_top)
right_min_top = -7
right_max_top = -2
ax2_top.set_ylim(right_min_top, right_max_top)

n_ticks_top = 6
ax1_top.set_yticks(np.linspace(left_min_top, left_max_top, n_ticks_top))
ax2_top.set_yticks(np.linspace(right_min_top, right_max_top, n_ticks_top))


lines1_top, labels1_top = ax1_top.get_legend_handles_labels()
lines2_top, labels2_top = ax2_top.get_legend_handles_labels()
ax1_top.legend(lines1_top + lines2_top, labels1_top + labels2_top,
           fontsize=16, edgecolor='black', frameon=True,
           loc='lower left', ncol=2)

for spine in ax1_top.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(2)
for spine in ax2_top.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(2)

ax1_top.text(0.01, 1.13, '(f)', transform=ax1_top.transAxes,
         fontsize=24, color='black', ha='left', va='top', fontweight='bold',
         bbox=dict(facecolor='white', alpha=0.5, edgecolor='none', boxstyle='square,pad=0.3'))

ax1_top.tick_params(axis='y', colors=(231/255,55/255,60/255))
ax2_top.tick_params(axis='y', colors=(78/255,197/255,171/255))
ax2_top.spines['right'].set_color((78/255,197/255,171/255))
ax2_top.spines['left'].set_color((231/255,55/255,60/255))

ax1_top.grid(True, axis='x', linestyle='--', color='dimgrey', linewidth=1.5, alpha=0.8)


color_ctrl_along = (230/255,76/255,255/255)
color_nosm_along = (234/255,98/255,112/255)
ax1_bottom.plot(time, mean_BWD_t, label="CTRL (along)",
         color=color_ctrl_along, linewidth=3, linestyle='-', marker='s', markersize=8)
ax1_bottom.plot(time, mean_BWD_t_sm, label="NO_SM (along)",
         color=color_nosm_along, linewidth=3, linestyle='-', marker='s', markersize=8)

ax1_bottom.set_ylabel("0–6 km BWD along", fontsize=25, labelpad=10, color='black')
ax1_bottom.tick_params(axis='y', labelsize=20, width=2, direction='out')


ax2_bottom = ax1_bottom.twinx()
color_ctrl_normal = (137/255,80/255,29/255)
color_nosm_normal = (33/255,113/255,181/255)
ax2_bottom.plot(time, mean_BWD_n, label="CTRL (normal)",
         color=color_ctrl_normal, linewidth=3, linestyle='-.')
ax2_bottom.plot(time, mean_BWD_n_sm, label="NO_SM (normal)",
         color=color_nosm_normal, linewidth=3, linestyle='-.')

ax2_bottom.set_ylabel("0–6 km BWD normal", fontsize=25, labelpad=10, color='black')
ax2_bottom.tick_params(axis='y', labelsize=20, width=2, direction='out')

left_min_bottom = 9.5
left_max_bottom = 13.5
ax1_bottom.set_ylim(left_min_bottom, left_max_bottom)
right_min_bottom = -11
right_max_bottom = -3
ax2_bottom.set_ylim(right_min_bottom, right_max_bottom)

n_ticks_bottom = 5
ax1_bottom.set_yticks(np.linspace(left_min_bottom, left_max_bottom, n_ticks_bottom))
ax2_bottom.set_yticks(np.linspace(right_min_bottom, right_max_bottom, n_ticks_bottom))

lines1_bottom, labels1_bottom = ax1_bottom.get_legend_handles_labels()
lines2_bottom, labels2_bottom = ax2_bottom.get_legend_handles_labels()
ax1_bottom.legend(lines1_bottom + lines2_bottom, labels1_bottom + labels2_bottom,
           fontsize=16, edgecolor='black', frameon=True,
           loc='lower left', ncol=2)


for spine in ax1_bottom.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(2)
for spine in ax2_bottom.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(2)

ax1_bottom.text(0.01, 1.13, '(e)', transform=ax1_bottom.transAxes,zorder = 10,
         fontsize=24, color='black', ha='left', va='top', fontweight='bold',
         bbox=dict(facecolor='white', alpha=1, edgecolor='none', boxstyle='square,pad=0.3'))

ax1_bottom.tick_params(axis='y', colors=(230/255,76/255,255/255))
ax2_bottom.tick_params(axis='y', colors=(137/255,80/255,29/255))
ax2_bottom.spines['right'].set_color((137/255,80/255,29/255))
ax2_bottom.spines['left'].set_color((230/255,76/255,255/255))

ax1_bottom.grid(True, axis='x', linestyle='--', color='dimgrey', linewidth=1.5, alpha=0.8)

ax1_top.set_xlabel("Time on May 7 (UTC)", fontsize=25, labelpad=15)
xtick_times = time[::6]
ax1_top.set_xticks(xtick_times)
ax1_top.set_xticklabels([t.strftime('%H%M') for t in xtick_times], fontsize=18)
ax1_top.tick_params(axis='x', labelsize=22, width=2)

plt.tight_layout()
plt.subplots_adjust(hspace=0.2)  


plt.savefig('/', dpi=600, bbox_inches="tight")
plt.show()