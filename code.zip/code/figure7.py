def plot_rain_distribution(ax, lons, lats, rain_data, max_lon, max_lat, max_value,
                           levels, cmap, norm, provinces, wrf_proj, title, is_left=False):
 
    im = ax.contourf(
        to_np(lons), to_np(lats), to_np(rain_data),
        levels=levels, cmap=cmap, norm=norm,
        transform=ccrs.PlateCarree(), alpha=1
    )

    ax.plot(max_lon, max_lat, marker='^', color=(0.691289, 0.268295, 0.981126), markersize=25,
             markerfacecolor='none', markeredgewidth=2.2, transform=ccrs.PlateCarree())
    ax.text(0.69, 0.42, f"{max_value.values:.1f}", transform=ax.transAxes, fontsize=25, #fontweight='bold', 
             va='top', ha='left', color=(0.691289, 0.268295, 0.981126))
 
    ax.add_feature(provinces, edgecolor='grey', linewidth=1.8)
    ax.set_extent([116.3,119,23.1,25.3], crs=ccrs.PlateCarree())
 
    gl = ax.gridlines(color="black", linestyle="dotted", draw_labels=True, x_inline=False, y_inline=False)
    gl.top_labels = False
    gl.right_labels = False
    gl.rotate_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    gl.xlocator = MultipleLocator(2) 
    gl.xlocator = FixedLocator(np.arange(115, 120, 1))
    gl.ylocator = MultipleLocator(1)  
    gl.xlabel_style = {'size': 28}
    gl.ylabel_style = {'size': 28}
    if not is_left:
        gl.left_labels = False 
    else:
        gl.left_labels = True 
        
    ax.tick_params(axis='both', labelsize=28, labelcolor='k', direction='out', length=5, width=1.5)
    for spine in ax.spines.values():
            spine.set_edgecolor('black')  
            spine.set_linewidth(1.5)      

    ax.text(0.03, 0.96, title, fontsize=30, fontweight = 'bold', transform=ax.transAxes, va='top', ha='left',
            bbox=dict(facecolor='white', alpha=0.5, edgecolor='white', boxstyle='round,pad=0.3'))
    
    return im


def main():
    shp_path = '/public/home/acbb7vqhjq/zji/salem_shp/China_shp_lqy/'
    provinces = cfeature.ShapelyFeature(
        Reader(shp_path + 'province.shp').geometries(),
        ccrs.PlateCarree(), edgecolor='k', facecolor='none'
    )
    rain_data_1 = total_rain[132] - total_rain[54]
    rain_data_2 = total_rain_sm[132] - total_rain_sm[54]
    rain_data_3 = total_rain_meso[132] - total_rain_meso[54]

    fig, axes = plt.subplots(1, 3, figsize=(20, 8), subplot_kw={'projection': wrf_proj}, gridspec_kw={'wspace': 0.05})
    
    im1 = plot_rain_distribution(
        axes[0], lons, lats, rain_data_1, lon_max_ctrl, lat_max_ctrl, ctrl_max,
        levels_acc, cmap_acc, norm_acc, provinces, wrf_proj, "(a) CTRL", is_left=True,
    )

    im2 = plot_rain_distribution(
        axes[1], lons, lats, rain_data_2, lon_max_sm, lat_max_sm, sm_max,
        levels_acc, cmap_acc, norm_acc, provinces, wrf_proj, "(b) NO_SM",is_left=False,
    )  

    im3 = plot_rain_distribution(
        axes[2], lons, lats, rain_data_3, lon_max_meso, lat_max_meso,meso_max,
        levels_acc, cmap_acc, norm_acc, provinces, wrf_proj, "(c) NO_MESO",is_left=False,
    )
    
    lon_min, lon_max = 116.9, 117.85
    lat_min, lat_max = 23.7, 24.45
    rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
    rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]

    axes[0].plot(rotated_lons, rotated_lats, color='red', linewidth=3, transform=ccrs.PlateCarree(), linestyle='--')
    l = 0.92
    b = 0.23
    w = 0.02
    h = 0.48
    rect = [l, b, w, h]
    cbar_ax = fig.add_axes(rect)
    cbar = fig.colorbar(im1, cax=cbar_ax, orientation='vertical')
    cbar.ax.text(0.5, 1.05, 'mm', fontsize=20, va='center', ha='center', transform=cbar.ax.transAxes)
    cbar.ax.tick_params(labelsize=28)
    cbar.set_ticks([0, 0.1, 1, 10, 25, 50, 100, 150, 200])
    cbar.ax.yaxis.set_major_formatter(FuncFormatter(
        lambda value, _: f"{value:.1f}" if value == 0.1 else f"{int(value)}"
    ))
    cbar.ax.tick_params(axis='y', labelsize=20, labelcolor='k', direction='out', length=5, width=1.5)
    for spine in cbar.ax.spines.values():
                spine.set_edgecolor('black') 
                spine.set_linewidth(1)    

    plt.savefig('/', dpi=300, bbox_inches="tight")
    plt.show()

# 执行主程序
main()




fig, ax1 = plt.subplots(figsize=(15, 7.5))

ax1.bar(time_numeric - offset, max_rain_ctrl_plot, width=bar_width, color=(229/255,28/255,63/255), label='CTRL')
ax1.bar(time_numeric, max_rain_sm_plot, width=bar_width, color=(106/255,193/255,133/255), label='NO_SM')
ax1.bar(time_numeric + offset, max_rain_meso_plot, width=bar_width, color=(246/255,147/255,53/255), label='NO_MESO')

ax1.set_xlabel('Time on May 7 (UTC)', fontsize=30, labelpad=15)
ax1.set_ylabel('Maximum Precipitation (mm)', fontsize=30, labelpad=15)

xtick_times = time[::1]  

ax1.set_xticks(xtick_times)

ax1.set_xticklabels([pd.to_datetime(t).strftime('%H%M') for t in xtick_times], fontsize=20)
ax1.tick_params(axis='x', labelsize=25, labelcolor='k', direction='out', length=5, width=2)
ax1.tick_params(axis='y', labelsize=25, labelcolor='k', direction='out', length=5, width=2)
ax1.grid(True, axis='y', linestyle='--', color='dimgrey', linewidth=1.5, alpha=0.8)

ax2 = ax1.twinx()
ax2.plot(time, subset_rain, color=(42/255,120/255,142/255), linewidth=4, linestyle='-', 
         marker='o',markersize = 10, label='CTRL')
ax2.plot(time, subset_rain_sm, color='royalblue', linewidth=4, linestyle='-', 
         marker='o', markersize = 10,label='NO_SM')
ax2.plot(time, subset_rain_meso, color=(121/255,81/255,160/255), linewidth=4, linestyle='-', 
         markersize = 10,marker='o', label='NO_MESO')
ax2.set_ylabel('Averaged precipitation (mm)', fontsize=30, labelpad=15, color='black')
ax2.tick_params(axis='both', labelsize=25, labelcolor='black', direction='out', length=5, width=2)

legend = ax1.legend(loc='upper left',fontsize=22, edgecolor='black', frameon=True)
legend.get_frame().set_linewidth(1) 
legend2 = ax2.legend(loc='upper right', fontsize=22, edgecolor='black', frameon=True)
legend2.get_frame().set_linewidth(1)


left_min = 0
left_max = 70  
ax1.set_ylim(left_min, left_max)


right_min = 0
right_max = 7
ax2.set_ylim(right_min, right_max)

n_ticks = 8 
ax1.set_yticks(np.linspace(left_min, left_max, n_ticks))
n_ticks = 8 
ax2.set_yticks(np.linspace(right_min, right_max, n_ticks))


ax1.tick_params(axis='y', colors=(229/255,28/255,63/255))  
ax1.yaxis.label.set_color((229/255,28/255,63/255))       
ax1.spines['left'].set_color((229/255,28/255,63/255))    

ax2.tick_params(axis='y', colors=(42/255,120/255,142/255))  
ax2.yaxis.label.set_color((42/255,120/255,142/255))         
ax2.spines['right'].set_color((42/255,120/255,142/255))     


for spine in ax1.spines.values():
    spine.set_edgecolor('k')  
    spine.set_linewidth(2)      

for spine in ax2.spines.values():
    spine.set_edgecolor('k')
    spine.set_linewidth(2)       

ax2.spines['left'].set_color((229/255,28/255,63/255))     
ax2.spines['right'].set_color((42/255,120/255,142/255))  
ax1.text(0.01, 1.08, '(d)', fontsize=30, fontweight = 'bold', transform=ax1.transAxes, va='top', ha='left',
            bbox=dict(facecolor='white', alpha=0.5, edgecolor='white', boxstyle='round,pad=0.3'))
    

plt.tight_layout()
plt.savefig('/', dpi=600, bbox_inches="tight")
plt.show()