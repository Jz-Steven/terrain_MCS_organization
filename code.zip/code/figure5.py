fig, axs = plt.subplots(3, 1, figsize=(8, 16), dpi=300, 
                        subplot_kw={'projection': ccrs.PlateCarree()})

plt.subplots_adjust(left=0.05, right=0.9, bottom=0.2, top=0.95, wspace=0.05)

last_topo = None
last_sc = None


for i, time_str in enumerate(time_strings):
    ax = axs[i]  
    target_time = pd.to_datetime(time_str)

    plot_data = combined_df[
        (combined_df['datetime'] == target_time) & 
        (combined_df['latitude'] >= 22.1) & (combined_df['latitude'] <= 25.4) &
        (combined_df['longitude'] >= 116) & (combined_df['longitude'] <= 119)
    ].copy()
  
 
    f_path = find_file_by_time(target_moments[i], base_dir)    
   
    f = CinradReader(f_path)
    rl = list(f.iter_tilt(230, 'REF'))
    cr = quick_cr(rl)
    
    lon_grid, lat_grid = get_latlon_grid(cr, site_lon, site_lat)

    mesh = ax.contour(lon_grid, lat_grid, cr['CR'], levels=[35],colors=['magenta'],
                      linestyles=['solid'], linewidths=1,transform=ccrs.PlateCarree(),zorder = 3
                        )

 
    plot_data['rad'] = np.deg2rad(plot_data['wind_dir_2min'])
    plot_data['u'] = -plot_data['wind_speed_2min'] * np.sin(plot_data['rad'])
    plot_data['v'] = -plot_data['wind_speed_2min'] * np.cos(plot_data['rad'])

    ax.set_extent([116.8,118.5,23.3,25], crs=ccrs.PlateCarree())


    shp_path = '/public/home/acbb7vqhjq/zji/salem_shp/China_shp_lqy/'
    try:
        provinces = cfeature.ShapelyFeature(
            Reader(shp_path + 'province.shp').geometries(),
            ccrs.PlateCarree(), 
            edgecolor='dimgrey', facecolor='none', linewidth=1, zorder=1,
        )
        ax.add_feature(provinces)
    except:
        ax.coastlines(resolution='10m', color='black', linewidth=1)


    last_topo = ax.contourf(
        lon_1, lat_1, hgt_1,
        levels=levels_ter,
        cmap=cmap_ter, 
        norm=norm_ter,
        transform=ccrs.PlateCarree(), 
        alpha=1,                    
        zorder=0,
        extend='max'
    )

    last_sc = ax.scatter(
        plot_data['longitude'], 
        plot_data['latitude'], 
        c=plot_data['current_temp'], 
        cmap=cmap_t, 
        s=20,  
        alpha=1, 
        zorder=2,
        norm=norm_t,
        transform=ccrs.PlateCarree() 
    )


    wind_data = plot_data.dropna(subset=['u', 'v'])
    
    Q = ax.quiver(
        wind_data['longitude'].values, 
        wind_data['latitude'].values, 
        wind_data['u'].values, 
        wind_data['v'].values,
        color='k', alpha=0.9,
        scale=120,        
        width=0.003,
        headwidth=8, 
        headlength=8, 
        zorder=3,
        transform=ccrs.PlateCarree()
    )


    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True, 
                      linewidth=1, color='gray', alpha=0.5, linestyle='--')
    
    gl.top_labels = False   
    gl.right_labels = False 
    
 
    if i > 0:
        gl.left_labels = True
    else:
        gl.left_labels = True
        
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    gl.xlocator = FixedLocator(np.arange(115, 120, 1))  
    gl.ylocator = MultipleLocator(0.5)                 

    gl.xlabel_style = {'size': 22, 'color': 'black'}
    gl.ylabel_style = {'size': 22, 'color': 'black'}

    time_hhmm = target_time.strftime('%H%M')
    
    label_text = f"{subplot_labels[i]} {time_hhmm} UTC"
    

    ax.text(0.04, 0.86, label_text, transform=ax.transAxes, 
            fontsize=25, fontweight='bold', ha='left', va='bottom',
            bbox=dict(facecolor='white', alpha=0.7, edgecolor='white', boxstyle='round,pad=0.3'))
    for spine in ax.spines.values():
        spine.set_edgecolor('black')  # 设置边框颜色为黑色
        spine.set_linewidth(1.5)      # 设置边框线宽为1.5

# 保存
plt.savefig('/', bbox_inches='tight', dpi=600)
plt.show()





fig, axs = plt.subplots(3, 1, figsize=(8, 16), dpi=300, 
                        subplot_kw={'projection': ccrs.PlateCarree()})
plt.subplots_adjust(left=0.05, right=0.95, bottom=0.2, top=0.95, wspace=0.05)
last_im = None

for i, t in enumerate(time_indices):
    ax = axs[i] 

    ax.set_extent([116.8,118.5,23.3,25], crs=ccrs.PlateCarree())

    ax.add_feature(province_feature, linewidth=1)

    ax.contour(
        to_np(lons),
        to_np(lats),
        to_np(terrain_ctrl),
        levels=[300],
        colors=['lime'],
        linestyles=['solid'],
        linewidths=1.5,
        transform=ccrs.PlateCarree()
    )

    last_im = ax.contourf(
        to_np(lons),
        to_np(lats), 
        to_np((T2_ctrl - 273.15)[t]),
        cmap=cmap_t, 
        levels=levels_t, 
        norm=norm_t,
        extend='both',
        transform=ccrs.PlateCarree(), 
        alpha=1
    )

    n = 7
    Q = ax.quiver(
        to_np(lons[::n,::n]), 
        to_np(lats[::n,::n]),
        to_np(uv10_ctrl[t,0][::n,::n]),
        to_np(uv10_ctrl[t,1][::n,::n]),
        color='k', alpha= 0.9,
        scale=120,        
        width=0.003,    
        headwidth=8, 
        headlength=8, 
        zorder=3,
        transform=ccrs.PlateCarree()
    )

    if i == 2:  
        last_Q = Q
        last_ax = ax
   
    gl = ax.gridlines(color="grey", linestyle="dotted", draw_labels=True, x_inline=False, y_inline=False)
    gl.top_labels = False
    gl.right_labels = False
    gl.rotate_labels = False
    
    if i == 0:
        gl.left_labels = True
    else:
        gl.left_labels = True
        
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    gl.xlocator = MultipleLocator(1) 
    gl.ylocator = MultipleLocator(0.5) 
    gl.xlabel_style = {'size': 22} 
    gl.ylabel_style = {'size': 22} 

    time_val = pd.to_datetime(T2_ctrl[t].Time.values)
 
    time_str = time_val.strftime('%H%M')
    
    label_text = f"{subplot_labels[i]} {time_str} UTC"
    
    ax.text(0.04, 0.86, label_text, transform=ax.transAxes, 
            fontsize=25, fontweight='bold', ha='left', va='bottom',
            bbox=dict(facecolor='white', alpha=0.7, edgecolor='white', boxstyle='round,pad=0.3'))
    for spine in ax.spines.values():
            spine.set_edgecolor('black')  
            spine.set_linewidth(1.5)     


last_ax.quiverkey(
    last_Q, 
    0.9, 1.05,  
    10, 
    r'10 m/s', 
    labelpos='W',  
    coordinates='axes',  
    fontproperties={'size': 20},

)

# 保存
save_name = '/'
plt.savefig(save_name, dpi=600, bbox_inches='tight')
plt.show()