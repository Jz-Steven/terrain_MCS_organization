fig, axs = plt.subplots(1, 3, figsize=(19,6), sharey=True)
fig.subplots_adjust(hspace=0.18, wspace=0.1)

mdbz1 = axs[0].contourf(
    distances_ctrl,
    Time_correct[72:121],
    to_np(mdbz_inter[:49]),
    levels=levels_mdbz,
    zorder=0,
    cmap=cmap_mdbz,
    norm=norm_mdbz
)
axs[0].set_xlabel("Distance(km)", fontsize=25, labelpad=5)

coord_pairs = to_np(mdbz_inter.coords["xy_loc"])
latitudes = [pair.lat for pair in coord_pairs]

x_ticks = [0,50,100,150]  
x_tick_positions = [distances_ctrl[np.argmin(np.abs(np.array(distances_ctrl) - tick))] for tick in x_ticks]  # 找到对应的x坐标位置

axs[0].set_xticks(x_tick_positions)
axs[0].set_xticklabels(x_ticks)
axs[0].set_yticks(Time_correct[72:121][::6])
axs[0].yaxis.set_major_formatter(mdates.DateFormatter('%H%M'))
axs[0].tick_params(axis='both', labelsize=22, direction='out', length=5, width=1.5, pad=1)


axs[0].grid(True, axis='x', linestyle='--', color='dimgrey', linewidth=1.5, alpha=1)
for spine in axs[0].spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)
axs[0].text(0.03, 0.97, '(a) CTRL', transform=axs[0].transAxes,
              fontsize=30, color='black', ha='left', va='top',fontweight= 'bold',
              bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', boxstyle='round,pad=0.3'))

mdbz2 = axs[1].contourf(
    distances_sm,
    Time_correct[72:121],
    to_np(mdbz_inter_sm[:49]),
    levels=levels_mdbz,
    zorder=0,
    cmap=cmap_mdbz,
    norm=norm_mdbz
)

axs[1].set_xlabel("Distance(km)", fontsize=25, labelpad=5)
axs[1].set_xticks(x_tick_positions)
axs[1].set_xticklabels(x_ticks)
axs[1].tick_params(axis='both', labelsize=22, direction='out', length=5, width=1.5, pad=1)
axs[1].grid(True, axis='x', linestyle='--', color='dimgrey', linewidth=1.5, alpha=0.8)
for spine in axs[1].spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)
axs[1].text(0.03, 0.97, '(b) NO_SM', transform=axs[1].transAxes,
              fontsize=30, color='black', ha='left', va='top', fontweight= 'bold',
              bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', boxstyle='round,pad=0.3'))


mdbz3 = axs[2].contourf(
    distances_sm,
    Time_correct[72:121],
    to_np(mdbz_inter_meso[:49]),
    levels=levels_mdbz,
    zorder=0,
    cmap=cmap_mdbz,
    norm=norm_mdbz
)

axs[2].set_xlabel("Distance(km)", fontsize=25, labelpad=5)
axs[2].set_xticks(x_tick_positions)
axs[2].set_xticklabels(x_ticks)
axs[2].tick_params(axis='both', labelsize=22, direction='out', length=5, width=1.5, pad=1)
axs[2].grid(True, axis='x', linestyle='--', color='dimgrey', linewidth=1.5, alpha=0.8)
for spine in axs[2].spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)
axs[2].text(0.03, 0.97, '(c) NO_MESO', transform=axs[2].transAxes,
              fontsize=30, color='black', ha='left', va='top', fontweight= 'bold',
              bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', boxstyle='round,pad=0.3'))

cbar_ax = fig.add_axes([0.155, -0.18, 0.7, 0.05])
cbar = fig.colorbar(mdbz1, cax=cbar_ax, orientation='horizontal')
cbar.set_ticks([5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70])
cbar.ax.tick_params(labelsize=25)
cbar.ax.set_title('Maximum Reflectivity [dBZ]', fontsize=22, pad=6)
cbar.ax.tick_params(axis='x', labelsize=25, labelcolor='k', direction='out', length=5, width=1)
for spine in cbar.ax.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1)
fig.text(0.04, 0.5, 'Time on May 7 (UTC)', va='center', rotation='vertical', fontsize=28)
axs[1].text(0.01, -0.08, 'SW', fontsize=18, va='top', ha='left', transform=axs[1].transAxes)
axs[1].text(0.93, -0.08, 'NE', fontsize=18, va='top', ha='left', transform=axs[1].transAxes)
axs[0].text(0.01, -0.08, 'SW', fontsize=18, va='top', ha='left', transform=axs[0].transAxes)
axs[0].text(0.93, -0.08, 'NE', fontsize=18, va='top', ha='left', transform=axs[0].transAxes)
axs[2].text(0.01, -0.08, 'SW', fontsize=18, va='top', ha='left', transform=axs[2].transAxes)
axs[2].text(0.93, -0.08, 'NE', fontsize=18, va='top', ha='left', transform=axs[2].transAxes)
plt.savefig('/', dpi=300, bbox_inches='tight')
plt.show()