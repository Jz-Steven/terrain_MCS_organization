def plot_combined(lon_grid, lat_grid, wind_u, wind_v, temp_700, gh_500, q_925, 
                  aws_lon_list, aws_lat_list, cumulative_prcp_12, cmap_acc, norm_acc):
    """
    Combine two plots (precipitation and weather data) into one figure horizontally.
    """

    fig, axes = plt.subplots(1, 2, figsize=(24, 10),
                             subplot_kw={'projection': ccrs.PlateCarree()}, gridspec_kw={'wspace': 0.15})
    
 
    ax1 = axes[0]

    ax1.set_extent([116.3,119,23.1,25.3])
    ax1.patch.set_fill(False)
    proj = ccrs.PlateCarree()
    shp_path = '/public/home/acbb7vqhjq/zji/salem_shp/China_shp_lqy/'
    
 
    provinces = cfeature.ShapelyFeature(
        Reader(shp_path + 'province.shp').geometries(),
        proj, edgecolor='dimgrey',
        facecolor='none'
    )
    ax1.add_feature(provinces, linewidth=1.5)
    ax1.set_xticks(np.arange(116.5, 119, 1), crs=ccrs.PlateCarree())
    ax1.set_yticks(np.arange(23.5, 25, 1), crs=ccrs.PlateCarree())
    ax1.tick_params(axis='both', which='major',labelsize=30, labelcolor='k', direction='out', length=5, width=1.5)
    lon_formatter = LongitudeFormatter()
    lat_formatter = LatitudeFormatter()
    ax1.xaxis.set_major_formatter(lon_formatter)
    ax1.yaxis.set_major_formatter(lat_formatter)

 
    sc = ax1.scatter(aws_lon_list, aws_lat_list, c=cumulative_prcp_12[13, :],
                     cmap=cmap_acc, s=300, edgecolor=None, norm=norm_acc, alpha=0.85)

    threshold = 100  
    lon_threshold = 116.5  

    low_value_mask = cumulative_prcp_12[13] < threshold
    high_value_mask = cumulative_prcp_12[13] >= threshold

    ax1.scatter(np.array(aws_lon_list[0])[high_value_mask ], 
                np.array(aws_lat_list[0])[high_value_mask ],
                c=cumulative_prcp_12[13][high_value_mask ], 
                cmap=cmap_acc, s=250,
                edgecolor=None, norm=norm_acc, alpha=0.65)

    threshold = 150 
    low_value_mask = cumulative_prcp_12[13] < threshold
    high_value_mask = cumulative_prcp_12[13] >= threshold
   
    ax1.scatter(np.array(aws_lon_list[0])[high_value_mask], np.array(aws_lat_list[0])[high_value_mask],
                c=cumulative_prcp_12[13][high_value_mask], cmap=cmap_acc, s=250,
                edgecolor=None,  norm=norm_acc, alpha=0.65)
 
    threshold = 200  
    lon_threshold = 116.5  # 经度阈值，160°E
  
    low_value_mask = cumulative_prcp_12[13] < threshold
    high_value_mask = cumulative_prcp_12[13] >= threshold
  
    
    ax1.scatter(np.array(aws_lon_list[0])[high_value_mask], 
                np.array(aws_lat_list[0])[high_value_mask],
                c=cumulative_prcp_12[13][high_value_mask], 
                cmap=cmap_acc, s=250,
                edgecolor=None, norm=norm_acc, alpha=0.65)
   
    max_value = np.nanmax(cumulative_prcp_12[13])
    max_indices = np.where(cumulative_prcp_12[13] == max_value)
   
    max_lon = np.array(aws_lon_list[0])[max_indices]
    max_lat = np.array(aws_lat_list[0])[max_indices]       
   
    ax1.scatter(max_lon, max_lat, c = max_value, 
                cmap=cmap_acc, s=200, edgecolor=None, norm=norm_acc, alpha=0.8)
   
    ax1.plot(118.08, 24.48, marker='+', color='lime', markersize=30,
             markerfacecolor='none', markeredgewidth=3, transform=ccrs.PlateCarree())
    ax1.plot(max_lon, max_lat, marker='^', color='magenta', markersize=30,
             markerfacecolor='none', markeredgewidth=3, transform=ccrs.PlateCarree())

   
    cbar1 = plt.colorbar(sc, ax=ax1, orientation='vertical', shrink=0.75)
    cbar1.ax.set_title('mm', fontsize=22, pad=10)
    custom_ticks = [0, 0.1, 1, 10, 25, 50, 100, 150, 200]
    cbar1.set_ticks(custom_ticks)
    cbar1.ax.tick_params(axis='y', which='major',labelsize=22, labelcolor='k', direction='out', length=5, width=1)
    cbar1.ax.yaxis.set_major_formatter(FuncFormatter(
        lambda value, _: f"{value:.1f}" if value == 0.1 else f"{int(value)}"
    ))

  
    ax1.text(0.01, 1.085, '(a) ', transform=ax1.transAxes, fontsize=30, fontweight='bold', 
             va='top', ha='left', color='black')
    ax1.text(0.82, 0.47, '290.5', transform=ax1.transAxes, fontsize=25, #fontweight='bold', 
             va='top', ha='left', color="magenta")
    ax1.text(0.7, 0.75, 'XM', transform=ax1.transAxes, fontsize=35, fontweight='bold', 
             va='top', ha='left', color='lime')
  
   
    ax2 = axes[1]
    ax2.set_extent([np.min(lon_grid), np.max(lon_grid), np.min(lat_grid), np.max(lat_grid)])
    provinces = cfeature.ShapelyFeature(
        Reader(shp_path + 'province.shp').geometries(),
        proj, edgecolor='grey', facecolor='none'
    )
    ax2.add_feature(provinces, edgecolor='dimgrey', linewidth=1.5)

 
    ax2.set_xticks(np.arange(110, 126, 5), crs=ccrs.PlateCarree())
    ax2.set_yticks(np.arange(20, 36, 5), crs=ccrs.PlateCarree())
    ax2.tick_params(axis='both', which='major',labelsize=30, labelcolor='k', direction='out', length=5, width=1.5)
    ax2.xaxis.set_major_formatter(LongitudeFormatter())
    ax2.yaxis.set_major_formatter(LatitudeFormatter())

    
    contour_temp = ax2.contourf(lon_grid, lat_grid, temp_700, levels=levels_t, cmap=cmap_t, norm=norm_t,
                                transform=ccrs.PlateCarree(), extend='both')

    
    mask_q = q_925 >= 16
    plt.rcParams['hatch.color']='green'
    ax2.contourf(lon_grid, lat_grid, mask_q, levels=[0.5, 1], colors='none',
                 hatches=['-'], transform=ccrs.PlateCarree())
    ax2.contour(lon_grid, lat_grid, mask_q, levels=[0.5], colors='forestgreen', linestyles='--', linewidths=2.5,
                transform=ccrs.PlateCarree(), alpha=1)

   
    quiver_slices = (slice(None, None, 5), slice(None, None, 5)) 
    ax2.barbs(lon_grid[quiver_slices], lat_grid[quiver_slices],
              wind_u[quiver_slices], wind_v[quiver_slices],
              length=7, linewidth=1.5, color='black', transform=ccrs.PlateCarree(),
              barb_increments={'half': 2, 'full': 4, 'flag': 20})

    
    levels_gh = np.arange(5760, 5900, 40)
    contour_gh = ax2.contour(lon_grid, lat_grid, gh_500, levels=levels_gh, colors='b', linewidths=2.5, zorder=3)
    ax2.clabel(contour_gh, fontsize=15, inline=5, inline_spacing=14, fmt='%i', colors='b')

    
    cbar2 = plt.colorbar(contour_temp, ax=ax2, ticks=levels_t, extend='both', shrink=0.75)
    cbar2.ax.set_title('K', fontdict={'size': 22}, pad=5)
    cbar2.ax.tick_params(axis='y', which='major',labelsize=22, labelcolor='k', direction='out', length=5, width=1)

   
    ax2.text(0.01, 1.085, '(b)', transform=ax2.transAxes, fontsize=30, fontweight='bold', 
             va='top', ha='left', color='black')
    ax2.plot(max_lon, max_lat, marker='^', color='cyan', markersize=30,
             markerfacecolor='none', markeredgewidth=3, transform=ccrs.PlateCarree())
    
    
    box1 = ax1.get_position()
    box2 = ax2.get_position()
    
    new_height = min(box1.height, box2.height)
    new_width = min(box1.width, box2.width)
    ax1.set_position([box1.x0, box1.y0, new_width, new_height])
    ax2.set_position([box1.x0+0.4, box1.y0, new_width, new_height])

    for spine in ax1.spines.values():
        spine.set_edgecolor('black')  # 设置边框颜色为黑色
        spine.set_linewidth(1.5)      # 设置边框线宽为1.5
    for spine in ax2.spines.values():
        spine.set_edgecolor('black')  # 设置边框颜色为黑色
        spine.set_linewidth(1.5)      # 设置边框线宽为1.5
    for spine in cbar1.ax.spines.values():
        spine.set_edgecolor('black')  # 设置边框颜色为黑色
        spine.set_linewidth(1)      # 设置边框线宽为1.5
    for spine in cbar2.ax.spines.values():
        spine.set_edgecolor('black')  # 设置边框颜色为黑色
        spine.set_linewidth(1)      # 设置边框线宽为1.5

    plt.savefig('/', dpi=300, bbox_inches="tight")
    plt.show()


# 调用合并绘图函数
plot_combined(
    lon_grid=lon_grid, 
    lat_grid=lat_grid, 
    wind_u=ds_geo.u[24, 2], 
    wind_v=ds_geo.v[24, 2], 
    temp_700=ds_geo.t[24, 3], 
    gh_500=geo_height[24, 4], 
    q_925=ds_geo.q[24, 1] * 1000,
    aws_lon_list=aws_lon_list, 
    aws_lat_list=aws_lat_list,
    cumulative_prcp_12=cumulative_prcp_12, 
    cmap_acc=cmap_acc, 
    norm_acc=norm_acc
)




csv_dir = '/data'  
csv_files = [f for f in os.listdir(csv_dir) if f.endswith('.csv')]
for csv_file in csv_files[0:1]:

    df = pd.read_csv(os.path.join(csv_dir, csv_file))
    df = df.sort_values(by='pressure', ascending=False)
    df = df.drop_duplicates(subset='pressure')
    try:
        timestamp_str = csv_file.split('_')[1].replace('.csv', '')
        timestamp = datetime.datetime.strptime(timestamp_str, '%Y%m%d%H')
    except IndexError:
        
        timestamp = datetime.datetime.now()
        print(f"Warning: Could not parse time from {csv_file}")
    

    p_vals = df['pressure'].values
    T_vals = df['temperature'].values
    Td_vals = df['dewpoint'].values
    u_vals = df['u_wind'].values
    v_vals = df['v_wind'].values

    mask_nan = ~np.isnan(p_vals) & ~np.isnan(T_vals) & ~np.isnan(Td_vals)
    p_vals = p_vals[mask_nan]
    T_vals = T_vals[mask_nan]
    Td_vals = Td_vals[mask_nan]
    u_vals = u_vals[mask_nan]
    v_vals = v_vals[mask_nan]


    sort_idx = np.argsort(p_vals)[::-1]
    p_vals = p_vals[sort_idx]
    T_vals = T_vals[sort_idx]
    Td_vals = Td_vals[sort_idx]
    u_vals = u_vals[sort_idx]
    v_vals = v_vals[sort_idx]

    _, unique_idx = np.unique(p_vals, return_index=True)

    unique_idx = np.sort(unique_idx)[::-1]
    
   
    p_vals = p_vals[unique_idx]
    T_vals = T_vals[unique_idx]
    Td_vals = Td_vals[unique_idx]
    u_vals = u_vals[unique_idx]
    v_vals = v_vals[unique_idx]

 
    p_plot = p_vals * units.hPa
    T_plot = T_vals * units.degC
    Td_plot = Td_vals * units.degC
    u_plot = u_vals * units.knots
    v_plot = v_vals * units.knots

    if p_plot[0] < p_plot[-1]:
        p_plot = p_plot[::-1]
        T_plot = T_plot[::-1]
        Td_plot = Td_plot[::-1]
        u_plot = u_plot[::-1]
        v_plot = v_plot[::-1]
   
    
    if np.any(np.diff(p_plot) >= 0):
        sort_inds = np.argsort(p_plot)[::-1]
        p_plot = p_plot[sort_inds]
        T_plot = T_plot[sort_inds]
        Td_plot = Td_plot[sort_inds]
        u_plot = u_plot[sort_inds]
        v_plot = v_plot[sort_inds]

    fig = plt.figure(figsize=(12, 12))
    skew = SkewT(fig, rotation=45, rect=[0.1, 0.1, 0.55, 0.85], aspect=100)


    skew.plot(p_plot, T_plot, 'r', linewidth=4, label='T')
    skew.plot(p_plot, Td_plot, 'royalblue', linewidth=4, label='Dewpoint')
    
  
    barb_increments = {'half': 2, 'full': 4, 'flag': 20}
    n = 1
    try:
        skew.plot_barbs(p_plot[::n], u_plot[::n], v_plot[::n], barb_increments=barb_increments, 
                        rounding=True, pivot='tip',
                        length=7, sizes=dict(emptybarb=0.1, spacing=0.15, height=0.35, width=0.25))
    except ValueError:
        print("Warning: Wind data shape mismatch, skipping barbs.")
    
 
    prof = mpcalc.parcel_profile(p_plot, T_plot[0], Td_plot[0]).to('degC')

    try:
        cape, cin = mpcalc.cape_cin(p_plot, T_plot, Td_plot, parcel_profile=prof)
  
    except Exception as e:
        print(f"CAPE/CIN calculation error: {e}")
    
  
    skew.ax.axvline(0, color='darkorange', linestyle='--', linewidth=2.5)
    
 
    skew.ax.set_ylim(1050, 150)
    skew.ax.set_xlim(-25, 50)
    
   
    skew.ax.tick_params(axis='x', labelsize=22, labelcolor='k', direction='out', length=5, width=1.5)
    skew.ax.tick_params(axis='y', labelsize=22, labelcolor='k', direction='out', length=5, width=1.5)
    skew.ax.set_xticks([-20, -10, 0, 10, 20, 30, 40])
    
  
    def short_minus_formatter(x, pos):
        return str(x).replace('\u2212', '-')
    
    skew.ax.xaxis.set_major_formatter(FuncFormatter(short_minus_formatter))
    skew.ax.tick_params(labelsize=20)
    
  
    mask = (p_plot >= 100 * units.hPa)
    p_mask_plot_moist_adiabats = p_plot[mask]
    
    skew.plot_dry_adiabats(t0=np.arange(-30, 160, 10) * units.degC, colors='grey', linewidths=1.5, linestyle='-', alpha=0.6)
    skew.plot_moist_adiabats(pressure=p_mask_plot_moist_adiabats,
                             colors='tab:green', linewidths=1.5, linestyle='-', alpha=0.6)
    skew.plot_mixing_lines(colors='tab:green', linewidths=1.5, alpha=0.6)
    
    skew.ax.set_xlabel('Temperature (°C)', fontsize=25, labelpad=10)
    skew.ax.set_ylabel('Pressure (hPa)', fontsize=25, labelpad=10)
    
   
    for spine in skew.ax.spines.values():
        spine.set_edgecolor('black')
        spine.set_linewidth(1.5)

 
    fig.patches.extend([plt.Rectangle((0.16, 0.25), 0.23, 0.08,
                                      edgecolor='black', facecolor='w', 
                                      linewidth=1.5, alpha=0.7, transform=fig.transFigure,
                                      figure=fig)])
    

    ml_t, ml_td = mpcalc.mixed_layer(p_plot, T_plot, Td_plot, depth=100 * units.hPa)

    try:
        mlcape, mlcin = mpcalc.mixed_layer_cape_cin(p_plot, T_plot, Td_plot, depth=100 * units.hPa)
    except Exception as e:
        mlcape, mlcin = 0 * units('J/kg'), 0 * units('J/kg')
        print(f"MLCAPE Calculation failed: {e}")
  
 
    plt.figtext(0.17, 0.27, 'MLCAPE: ',  fontsize=18, color='black', ha='left')
    plt.figtext(0.38, 0.27, f'{mlcape:.1f~P}', fontsize=18, color='darkblue', ha='right')
    plt.figtext(0.17, 0.30, 'MLCIN: ',  fontsize=18, color='black', ha='left')
    plt.figtext(0.38, 0.30, f'{mlcin:.1f~P}', fontsize=18, color='darkblue', ha='right')

 
    skewleg = skew.ax.legend(loc='upper left', fontsize=15)

 
    output_filename = os.path.join(output_dir, f"skewt_{timestamp.strftime('%Y%m%d%H')}_2026_0314.png")
    plt.savefig(output_filename, dpi=300, bbox_inches='tight')
   
    plt.show()
