def plot_panel(ax, time_idx, is_ctrl, title_text, ylim_val=3.1, show_ylabel=False, show_xlabel=False, show_time=False):

    if is_ctrl:
        xvort_plot = xvort_west_east_mean_ctrl.isel(time=time_idx) * 10**4
        dbz_plot = dbz_west_east_mean_ctrl.isel(time=time_idx)
        v_plot = v_west_east_mean_ctrl.isel(time=time_idx)
        w_plot = w_west_east_mean_ctrl.isel(time=time_idx)
        ht_time_data = ht_west_east_mean_ctrl.isel(time=time_idx)
        ter_data = ter_filled
        current_dbz_full = dbz_ctrl 
    else:
        xvort_plot = xvort_west_east_mean_sm.isel(time=time_idx) * 10**4
        dbz_plot = dbz_west_east_mean_sm.isel(time=time_idx)
        v_plot = v_west_east_mean_sm.isel(time=time_idx)
        w_plot = w_west_east_mean_sm.isel(time=time_idx)
        ht_time_data = ht_west_east_mean_sm.isel(time=time_idx)
        ter_data = ter_filled_sm
        current_dbz_full = dbz_ctrl 

    # --- 坐标设置 ---
    selected = [23.5, 23.7, 23.9, 24.1]
    actual = to_np(lat_plot)
    indices = [np.abs(actual - sel_lat).argmin() for sel_lat in selected]
    chosen = actual[indices]
    
    lats_2d, z_2d = np.meshgrid(lat_plot, ht_time_data[:, 0])

    cf = ax.contourf(lats_2d, z_2d, to_np(-xvort_plot),
                     cmap=cmap_vot, levels=levels_vot, norm=norm_vot, extend='both')

    ax.contour(lats_2d, z_2d, to_np(dbz_plot), levels=[35],
               linewidths=1.3, colors='magenta', linestyles='-')
    
    skip = (slice(None, None, 1), slice(None, None, 8)) 
    Q = ax.quiver(
        lats_2d[skip], z_2d[skip], 
        to_np(v_plot[skip]), 
        to_np(w_plot[skip] * 5),  
        scale=200, width=0.002,
        headlength=4, headwidth=4, headaxislength=4,
        alpha=1, linewidth=2
    )


    ax.fill_between(lats_2d[0], 0, to_np(ter_data), facecolor="saddlebrown", zorder=10)

    ax.set_xticks(chosen)
    if show_xlabel:
        ax.set_xticklabels([f"{lat:.1f}" for lat in chosen], fontsize=22)
        ax.set_xlabel("Latitude(°N)", fontsize=25, labelpad=10)
    else:
        ax.set_xticklabels([]) 

    ax.set_yticks([0, 1, 2, 3, 4])
    ax.set_ylim(0.02, ylim_val)
    ax.yaxis.set_minor_locator(tick.MultipleLocator(0.2))
    ax.yaxis.set_major_formatter(tick.FormatStrFormatter("%d"))
    ax.tick_params(axis='both', labelsize=22, width=1.5, length=5, direction='out')
    ax.tick_params(axis='y', which='minor', length=3)
    
    if show_ylabel:
        ax.set_ylabel("Height (km)", fontsize=25, labelpad=20) 

    ax.text(0.03, 0.97, title_text, transform=ax.transAxes,
             fontsize=25, color='black', ha='left', va='top', fontweight='bold',
             bbox=dict(facecolor='white', alpha=0.5, edgecolor='none', boxstyle='square,pad=0.3'))

    for spine in ax.spines.values():
        spine.set_edgecolor('black')
        spine.set_linewidth(1.5)


    return cf,Q

fig, axs = plt.subplots(2, 2, figsize=(12, 12), sharey=True, sharex=True)
plt.subplots_adjust(wspace=0.05, hspace=0.05) 

cf1 = plot_panel(
    axs[0, 0], 
    time_idx=0, 
    is_ctrl=True, 
    title_text='(a) 0300 UTC', 
    ylim_val=2.5, 
    show_ylabel=True, 
    show_xlabel=False,
    show_time=True
)

plot_panel(
    axs[0, 1], 
    time_idx=0, 
    is_ctrl=False, 
    title_text='(b) 0300 UTC', 
    ylim_val=2.5,
    show_ylabel=False, 
    show_xlabel=False,
    show_time=False
)

plot_panel(
    axs[1, 0], 
    time_idx=6, 
    is_ctrl=True, 
    title_text='(c) 0400 UTC',
    ylim_val=2.5,
    show_ylabel=True, 
    show_xlabel=True, 
    show_time=True
)


Q = plot_panel(
    axs[1, 1], 
    time_idx=6, 
    is_ctrl=False, 
    title_text='(d) 0400 UTC', 
    ylim_val=2.5,
    show_ylabel=False, 
    show_xlabel=True,
    show_time=False
)
axs[0, 0].set_title("CTRL", fontsize=30, fontweight='bold', pad=15)
axs[0, 1].set_title("NO_SM", fontsize=30, fontweight='bold', pad=15)
axs[1, 1].quiverkey(Q[1], 0.85, -0.15, 10, 
             label='10 m/s', 
             labelpos='E', 
             coordinates='axes',
             color='k',

cbar_ax = fig.add_axes([0.95, 0.15, 0.03, 0.7]) 
cbar = fig.colorbar(cf1[0], cax=cbar_ax, orientation='vertical', extend='both')
cbar.set_ticks([-100,-80,-60,-40,-20, 0, 20, 40, 60, 80, 100])
cbar.ax.tick_params(labelsize=20, direction='out', length=5, width=1)
for spine in cbar.ax.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1)
plt.savefig('/', dpi=300, bbox_inches="tight")
plt.show()