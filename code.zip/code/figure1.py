def mark_inset(parent_axes, inset_axes, loc1a=1, loc1b=1, loc2a=2, loc2b=2, **kwargs):
    rect = TransformedBbox(inset_axes.viewLim, parent_axes.transData)

    pp = BboxPatch(rect, fill=False, **kwargs)
    parent_axes.add_patch(pp)

    p1 = BboxConnector(inset_axes.bbox, rect, loc1=loc1a, loc2=loc1b, **kwargs)
    inset_axes.add_patch(p1)
    p1.set_clip_on(False)
    p2 = BboxConnector(inset_axes.bbox, rect, loc1=loc2a, loc2=loc2b, **kwargs)
    inset_axes.add_patch(p2)
    p2.set_clip_on(False)

    return pp, p1, p2


def add_equal_axes(ax, loc, pad, width,projection):
   
    axes = np.atleast_1d(ax).ravel()
    bbox = mtransforms.Bbox.union([ax.get_position() for ax in axes])

    if loc == 'left':
        x0_new = bbox.x0 - pad - width
        x1_new = x0_new + width
        y0_new = bbox.y0
        y1_new = bbox.y1
    elif loc == 'right':
        x0_new = bbox.x1 + pad
        x1_new = x0_new + width
        y0_new = bbox.y0
        y1_new = bbox.y1
    elif loc == 'bottom':
        x0_new = bbox.x0
        x1_new = bbox.x1
        y0_new = bbox.y0 - pad - width
        y1_new = y0_new + width
    elif loc == 'top':
        x0_new = bbox.x0
        x1_new = bbox.x1
        y0_new = bbox.y1 + pad
        y1_new = y0_new + width

    fig = axes[0].get_figure()
    bbox_new = mtransforms.Bbox.from_extents(x0_new, y0_new, x1_new, y1_new)
    ax_new = fig.add_axes(bbox_new,projection=projection)

    return ax_new




fig = plt.figure(figsize=(12,12))
plt.tight_layout()

ax=fig.add_axes([0.09,0.15,0.4,0.7],projection=wrf_proj)

proj = ccrs.PlateCarree()
shp_path = '/'

provinces = cfeature.ShapelyFeature(
        Reader(shp_path + 'province.shp').geometries(),
        proj, edgecolor='dimgrey',
        facecolor='none'
    )

shp_path_9 = '/'
gdf = gpd.read_file(shp_path_9)
gdf = gdf.to_crs(epsg=4326)

for geom in gdf.geometry:
    ax.add_geometries([geom], crs=ccrs.PlateCarree(), edgecolor='dimgrey', facecolor='none', linewidth=1)


ax.set_xlim(cartopy_xlim(hgt))
ax.set_ylim(cartopy_ylim(hgt))
ax.add_feature(cfeature.COASTLINE.with_scale('10m'), 
               linewidth=1, zorder=10,color='dimgrey')
contour = ax.contourf(to_np(lon), to_np(lat), to_np(hgt), transform=ccrs.PlateCarree(), 
                      cmap=cmap_ter, levels= levels_ter, norm=norm_ter, extend = 'both')

ax.add_feature(provinces, linewidth=1)


g1 = ax.gridlines(draw_labels=True, linewidth=1, color='k', alpha=0.5, linestyle='--',
                  x_inline=False, y_inline=False, xlocs=np.arange(112,120+1,4))

g1.top_labels = False
g1.right_labels = False
g1.xformatter = LONGITUDE_FORMATTER
g1.yformatter = LATITUDE_FORMATTER
g1.rotate_labels = False
g1.ylocator = MultipleLocator(4) 
g1.xlabel_style = {'size': 28}  
g1.ylabel_style = {'size': 28} 
ax.tick_params(axis='x', labelsize=28, labelcolor='k', direction='out', length=5, width=1.5, pad =7)
ax.tick_params(axis='y', labelsize=28, labelcolor='k', direction='out', length=5, width=1.5)

ax.plot([lon_1[0, 0], lon_1[-1, 0]], [lat_1[0, 0], lat_1[-1, 0]], color='k', lw=1.75, transform=ccrs.PlateCarree())
ax.plot([lon_1[-1, 0], lon_1[-1, -1]], [lat_1[-1, 0], lat_1[-1, -1]], color='k', lw=1.75, transform=ccrs.PlateCarree())
ax.plot([lon_1[-1, -1], lon_1[0, -1]], [lat_1[-1, -1], lat_1[0, -1]], color='k', lw=1.75, transform=ccrs.PlateCarree())
ax.plot([lon_1[0, -1], lon_1[0, 0]], [lat_1[0, -1], lat_1[0, 0]], color='k', lw=1.75, transform=ccrs.PlateCarree())

ax.text(0.02, 0.98, '(a) D01', fontweight = 'bold', fontsize=32, transform=ax.transAxes,
        ha='left', va='top',  # 水平和垂直对齐方式
        bbox=dict(facecolor='white', alpha=0.9, edgecolor='none', boxstyle='square,pad=0.2'))

ax1 = add_equal_axes(ax, loc='right', pad=0.05, width=0.4, projection=wrf_proj)
ax1.set_xlim(cartopy_xlim(hgt_1))
ax1.set_ylim(cartopy_ylim(hgt_1))
contour1 = ax1.contourf(to_np(lon_1), to_np(lat_1),hgt_1_data, transform=ccrs.PlateCarree(), 
                        cmap=cmap_ter, levels= levels_ter, norm=norm_ter, extend = 'both')

ax1.add_feature(provinces, linewidth=2,edgecolor='dimgrey')

g1 = ax1.gridlines(draw_labels=True, linewidth=1, color='k', alpha=0.5, linestyle='--',
                   x_inline=False, y_inline=False)
g1.top_labels = False
g1.left_labels = False
g1.xformatter = LONGITUDE_FORMATTER
g1.yformatter = LATITUDE_FORMATTER
g1.rotate_labels = False
g1.xlocator = MultipleLocator(2)  
g1.ylocator = MultipleLocator(2)  
g1.xlabel_style = {'size': 28}  
g1.ylabel_style = {'size': 28}  

ax1.tick_params(axis='x', labelsize=28, labelcolor='k', direction='out', length=5, width=1.5, pad =7)
ax1.tick_params(axis='y', labelsize=28, labelcolor='k', direction='out', length=5, width=1.5)

ax1.text(0.02, 0.98, '(b) D02', fontweight = 'bold', fontsize=30, transform=ax1.transAxes,
         ha='left', va='top',  # 水平和垂直对齐方式
         bbox=dict(facecolor='white', alpha=0.8, edgecolor='none', boxstyle='square,pad=0.2'))

ax1.text(0.2, 0.52, 'GD', fontsize=28, fontweight = 'bold', transform=ax1.transAxes, va='top', ha='left',)         
ax1.text(0.6, 0.8, 'FJ', fontsize=28, fontweight = 'bold', transform=ax1.transAxes, va='top', ha='left')


mark_inset(ax, ax1, loc1a=2, loc1b=1, loc2a=3, loc2b=4, fc='none', ec='black', lw=1.75)

l = 0.15
b = 0.2
w = 0.7
h = 0.03
rect = [l, b, w, h]
cbar_ax = fig.add_axes(rect)
cbar=plt.colorbar(contour,cax=cbar_ax,orientation='horizontal')
cbar.ax.text(1.06, 0.5, 'm', fontsize=25, va='center', ha='left', transform=cbar.ax.transAxes)
custom_ticks = [0, 500, 1000, 1500, 2000]
cbar.set_ticks(custom_ticks)
cbar.ax.tick_params(axis='x', labelsize=25, labelcolor='k', direction='out', length=5, width=1)

for spine in cbar.ax.spines.values():
        spine.set_edgecolor('black')  
        spine.set_linewidth(1)    
for spine in ax.spines.values():
        spine.set_edgecolor('black')  
        spine.set_linewidth(1.5)    
for spine in ax1.spines.values():
        spine.set_edgecolor('black')  
        spine.set_linewidth(1.5)      

lon_min, lon_max = 116.6, 117.6
lat_min, lat_max = 23.3, 24.4
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
ax1.plot(rect_lons, rect_lats, color='k', linewidth=2, transform=ccrs.PlateCarree(), linestyle='-', alpha = 0.8)
plt.show()
