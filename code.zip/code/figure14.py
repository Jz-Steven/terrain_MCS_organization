def plot_rain_distribution(ax, lons, lats, pt, terrain, div, u, v, mdbz,
                           levels, cmap, norm, wrf_proj, title, map_extent, 
                           is_left=False, is_bottom=False, show_div=False,show_ter=True, n=5):


    shp_path = '/public/home/acbb7vqhjq/zji/salem_shp/China_shp_lqy/'
    proj = ccrs.PlateCarree()
    provinces = cfeature.ShapelyFeature(
        Reader(shp_path + 'province.shp').geometries(),
        proj, edgecolor='grey',
        facecolor='none'
    )
    ax.add_feature(provinces, edgecolor='dimgrey', linewidth= 1.8)

    im = ax.contourf(to_np(lons),
                 to_np(lats), to_np(pt),
                 cmap=cmap_pt, levels=levels_pt, norm=norm_pt, extend='both',
                transform=ccrs.PlateCarree(), alpha=1)

    if show_ter:
        terrain_c = ax.contour(
        to_np(lons),
        to_np(lats),
        to_np(terrain),
        levels=[250],
        colors=['magenta'],
        linestyles=['solid'],
        linewidths=1.5,
        transform=ccrs.PlateCarree()
        )
        
        mask_ter = terrain >= 250
        plt.rcParams['hatch.color']='magenta'
        ax.contourf(to_np(lons), to_np(lats), mask_ter, levels=[0.5, 1], colors='none',
                     hatches=['-'], transform=ccrs.PlateCarree())

    mdbz_c = ax.contour(to_np(lons), to_np(lats), to_np(mdbz),levels=[35],
                        colors=['lime'], linestyles=['solid'], linewidths=2.5, transform=ccrs.PlateCarree(),alpha=1)

    if show_div:
        div_c = ax.contour(
            to_np(lons),
            to_np(lats),
            to_np(div),
            levels=[-250*10**(-5)],
            colors=['w'],
            linestyles=['solid'],
            linewidths=2.5,
            transform=ccrs.PlateCarree()
        )

        mask_div = div <= -250*10**(-5)
        plt.rcParams['hatch.color'] = 'w'
    
    u_sub = to_np(u[::n, ::n])
    v_sub = to_np(v[::n, ::n])
    lons_sub = to_np(lons[::n, ::n])
    lats_sub = to_np(lats[::n, ::n])
    
    speed = np.sqrt(u_sub**2 + v_sub**2)
    
    threshold = 0
    
    mask = speed >= threshold

    u_masked = np.where(mask, u_sub, np.nan)
    v_masked = np.where(mask, v_sub, np.nan)
    lons_masked = np.where(mask, lons_sub, np.nan)
    lats_masked = np.where(mask, lats_sub, np.nan)

    ax.barbs(
        lons_masked, lats_masked,
        u_masked, v_masked,
        linewidth=1, flagcolor='yellow', length=5.5, pivot='tip',
        barb_increments=dict(half=2, full=4, flag=20),
        transform=ccrs.PlateCarree(), zorder=11
    )

    ax.set_extent(map_extent, crs=ccrs.PlateCarree())

    gl = ax.gridlines(color="black", linestyle="dotted", draw_labels=True, x_inline=False, y_inline=False)
    gl.top_labels = False
    gl.right_labels = False
    gl.rotate_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    gl.ylocator = MultipleLocator(0.5)
    gl.xlocator = MultipleLocator(0.5)
    gl.xlabel_style = {'size': 25}
    gl.ylabel_style = {'size': 25}
    
    if not is_left:
        gl.left_labels = False
    else:
        gl.left_labels = True
        
    if not is_bottom:
        gl.bottom_labels = False
    else:
        gl.bottom_labels = True
        
    ax.tick_params(axis='both', labelsize=25, labelcolor='k', direction='out', length=5, width=1.5)

    for spine in ax.spines.values():
            spine.set_edgecolor('black')
            spine.set_linewidth(1.5)

    ax.text(0.04, 0.965, title, fontsize=30, fontweight='bold', transform=ax.transAxes, va='top', ha='left',
            bbox=dict(facecolor='white', alpha=0.7, edgecolor='white', boxstyle='round,pad=0.3'), zorder=13)
    
    return im

def main():
    shp_path = '/public/home/acbb7vqhjq/zji/salem_shp/China_shp_lqy/'

    pt_data_1 = vpt_sm[0,0]  #0120
    pt_data_2 = vpt_sm[1,0]  #0140
    pt_data_4 = vpt_sm[2,0]  #0200
    pt_data_5 = vpt_sm[3,0]  #0220
    pt_data_6 = vpt_sm[4,0]  
    pt_data_7 = vpt_sm[5,0]  

    fig, axes = plt.subplots(3, 2, figsize=(14, 20), 
                             subplot_kw={'projection': wrf_proj}, 
                             gridspec_kw={'hspace': 0.15, 'wspace': 0.01},
                             )
    
    i = 0
    im1 = plot_rain_distribution(
        axes[0,0], lons, lats, pt_data_1, ter_sm, div_sm[i,0], u_sm[i,0], v_sm[i,0], dbz_sm[i,0],
        levels_pt, cmap_pt, norm_pt, wrf_proj, "(a) 0120 UTC", [116.7, 117.6, 23.4, 24.2],
        is_left=True, is_bottom=True,show_div=True, n = 5
    )

    i = 1
    im2 = plot_rain_distribution(
        axes[0,1], lons, lats, pt_data_2, ter_sm, div_sm[i,0], u_sm[i,0], v_sm[i,0], dbz_sm[i,0],
        levels_pt, cmap_pt, norm_pt, wrf_proj, "(b) 0140 UTC", [116.7, 117.6, 23.4, 24.2],
        is_left=False, is_bottom=True,show_div=True, n = 5
    )  

    i = 2
    im3 = plot_rain_distribution(
        axes[1,0], lons, lats, pt_data_4, ter_sm, div_sm[i,0], u_sm[i,0], v_sm[i,0], dbz_sm[i,0],
        levels_pt, cmap_pt, norm_pt, wrf_proj, "(c) 0200 UTC", [116.7, 117.6, 23.4, 24.2],
        is_left=True, is_bottom=True, n = 5
    )  

    i = 3
    im4 = plot_rain_distribution(
        axes[1,1], lons, lats, pt_data_5, ter_sm, div_sm[i,0], u_sm[i,0], v_sm[i,0], dbz_sm[i,0],
        levels_pt, cmap_pt, norm_pt, wrf_proj, "(d) 0220 UTC", [116.7, 117.6, 23.4, 24.2],
        is_left=False, is_bottom=True, n = 5
    )  
 
    i = 4  
    im5 = plot_rain_distribution(
        axes[2,0], lons, lats, pt_data_6, ter_sm, div_sm[i,0], u_sm[i,0], v_sm[i,0], dbz_sm[i,0],
        levels_pt, cmap_pt, norm_pt, wrf_proj, "(e) 0300 UTC", [116.7, 117.9, 23.4, 24.5],
        is_left=True, is_bottom=True,show_ter=True, n = 8
    )

    i = 5  
    im6 = plot_rain_distribution(
        axes[2,1], lons, lats, pt_data_7, ter_sm, div_sm[i,0], u_sm[i,0], v_sm[i,0], dbz_sm[i,0],
        levels_pt, cmap_pt, norm_pt, wrf_proj, "(f) 0400 UTC", [116.7, 117.9, 23.4, 24.5],
        is_left=False, is_bottom=True,show_ter=True, n = 8
    )

    point1_lon, point1_lat = 117., 23.8 
    point2_lon, point2_lat = 117.43, 24.02  

    axes[1,1].plot([point1_lon, point2_lon], [point1_lat, point2_lat], color='w', linewidth=3, transform=ccrs.PlateCarree())
    point1_lon, point1_lat = 117., 23.8  
    point2_lon, point2_lat = 117.43, 24.02 

    axes[1,0].plot([point1_lon, point2_lon], [point1_lat, point2_lat], color='w', linewidth=3, transform=ccrs.PlateCarree())

    lon_min, lon_max = 117.1, 117.2
    lat_min, lat_max = 23.5, 24.3
    rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
    rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
    axes[2,0].plot(rect_lons, rect_lats, color='w', linewidth=2, transform=ccrs.PlateCarree(), linestyle='-', alpha = 1)
    axes[2,1].plot(rect_lons, rect_lats, color='w', linewidth=2, transform=ccrs.PlateCarree(), linestyle='-', alpha = 1)
    
    l = 0.18
    b = 0.04 
    w = 0.65
    h = 0.015
    rect = [l, b, w, h]
    cbar_ax = fig.add_axes(rect)
    cbar = fig.colorbar(im1, cax=cbar_ax, orientation='horizontal')
    cbar.ax.set_title('Virtual Potential Temperature [K]', fontsize=23, pad=6)
    cbar.ax.tick_params(labelsize=23)
    cbar.set_ticks([301,302,303,304,305,306,307])
    cbar.ax.tick_params(axis='x', labelsize=23, labelcolor='k', direction='out', length=5, width=1)
    
    for spine in cbar.ax.spines.values():
        spine.set_edgecolor('black')
        spine.set_linewidth(1)

    plt.savefig('/', dpi=600, bbox_inches="tight")
    plt.show()

main()