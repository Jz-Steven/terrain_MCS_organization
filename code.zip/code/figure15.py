fig, axs = plt.subplots(2, 2, figsize=(12, 12),sharey=True)
plt.subplots_adjust(wspace=0.1) 

time_idx = 2

ax1 = axs[0,0]
        
pt_diff_ctrl_plot = pt_cross_filled_ctrl[time_idx]
dbz_diff_ctrl_plot = dbz_cross_filled_ctrl[time_idx]
ws_projected_ctrl_plot = ws_projected_cross_filled_ctrl[time_idx]
w_ctrl_plot = w_cross_filled_ctrl[time_idx]

cf = ax1.contourf(distances_ctrl, ys, to_np(pt_diff_ctrl_plot),
                    cmap=cmap_pt_cross, levels=levels_pt_cross, norm=norm_pt_cross, extend='both')     
     
ht_fill = ax1.fill_between(distances_ctrl, 0, to_np(ter_line_ctrl/1000),                                
                                    facecolor="saddlebrown",zorder =10)

dbz_lines = ax1.contour(distances_ctrl,ys,to_np(dbz_diff_ctrl_plot),                   
                     levels=[35,45],             
                     linewidths=1.5,                  
                     colors=['lime','green'],                 
                     linestyles='-'                      
                    )

cp = ax1.contour(distances_ctrl,ys,to_np(pt_diff_ctrl_plot),                    
                     levels=[303],       
                     linewidths=2,                 
                     colors=['magenta'],                    
                     linestyles='dashed'                   
                    )
n = 5

xx, yy = np.meshgrid(distances_ctrl, ys)

skip = (slice(None, None, 1), slice(None, None, 3))  
Q = ax1.quiver(xx[skip], yy[skip], to_np(ws_projected_ctrl_plot[skip]), to_np(w_ctrl_plot[skip]*n), 
            scale=200,
            width=0.002,        
            headlength=7,      
            headwidth=4,        
            headaxislength=6,  
            alpha=1,          
            linewidth=2
            )

x_ticks = [0,10,20,30,40]  
x_tick_positions = [distances_ctrl[np.argmin(np.abs(np.array(distances_ctrl) - tick))] for tick in x_ticks]
x_ticks_sm = [0,10,20,30,40]
x_tick_positions_sm = [distances_sm[np.argmin(np.abs(np.array(distances_sm) - tick))] for tick in x_ticks_sm] 
ax1.set_xticks(x_tick_positions)
ax1.set_xticklabels(x_ticks, fontsize=20)              
ax1.set_yticks([0, 1,2])
ax1.set_ylim(0.0, 2.1)
ax1.yaxis.set_minor_locator(tick.MultipleLocator(0.2))
ax1.yaxis.set_major_formatter(tick.FormatStrFormatter("%d"))
ax1.tick_params(axis='both', labelsize=20, width=1.5, length=5, direction='out')
ax1.tick_params(axis='y', which='minor', length=3)
ax1.set_ylabel("Height (km)", fontsize=25, labelpad=10)      
for spine in ax1.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)
        
ax1.text(0.03, 0.97, '(a) 0200 UTC', transform=ax1.transAxes,
            fontsize=25, ha='left', va='top', fontweight='bold',
            bbox=dict(facecolor='white', alpha=0.8, edgecolor='none', boxstyle='round,pad=0.3'))


ax2 = axs[0,1]      
pt_diff_sm_plot = pt_cross_filled_sm[time_idx]    
dbz_diff_sm_plot = dbz_cross_filled_sm[time_idx]        
ws_projected_sm_plot = ws_projected_cross_filled_sm[time_idx]
w_sm_plot = w_cross_filled_sm[time_idx]

cf = ax2.contourf(distances_sm, ys_sm, to_np(pt_diff_sm_plot),
                    cmap=cmap_pt_cross, levels=levels_pt_cross, norm=norm_pt_cross, extend='both')

dbz_lines = ax2.contour(distances_sm,ys_sm,to_np(dbz_diff_sm_plot),                  
                     levels=[35,45],                   
                     linewidths=1.5,                  
                     colors=['lime','g'],               
                     linestyles='-'                    
                    )

cp = ax2.contour(distances_sm,ys_sm,to_np(pt_diff_sm_plot),                    
                     levels=[303],                   
                     linewidths=2,                 
                     colors=['magenta'],                    
                     linestyles='dashed'                      
                    )

xx, yy = np.meshgrid(distances_sm, ys_sm)

skip = (slice(None, None, 1), slice(None, None, 3)) 
Q = ax2.quiver(xx[skip], yy[skip], to_np(ws_projected_sm_plot[skip]), to_np(w_sm_plot[skip]*n), 
            scale=200,
            width=0.002,       
            headlength=7,        
            headwidth=4,         
            headaxislength=6,  
            alpha=1,           
            linewidth=2
            )
        
ax2.set_xticks(x_tick_positions_sm)
ax2.set_xticklabels(x_ticks_sm, fontsize=20) 
ax2.set_yticks([0, 1, 2])
ax2.set_ylim(0.0, 2.1)
ax2.yaxis.set_minor_locator(tick.MultipleLocator(0.2))
ax2.yaxis.set_major_formatter(tick.FormatStrFormatter("%d"))
ax2.tick_params(axis='both', labelsize=20, width=1.5, length=5, direction='out')
ax2.tick_params(axis='y', which='minor', length=3) 
ht_fill = ax2.fill_between(distances_sm, 0, to_np(ter_line_sm/1000),                                
                                    facecolor="saddlebrown",zorder =10)

for spine in ax2.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)
        
ax2.text(0.03, 0.97, '(b) 0200 UTC', transform=ax2.transAxes,
            fontsize=25, ha='left', va='top', fontweight='bold',
            bbox=dict(facecolor='white', alpha=0.8, edgecolor='none', boxstyle='round,pad=0.3'))

time_value = w_ctrl.Time.values[time_idx]
formatted_time = pd.Timestamp(time_value).strftime('%Y-%m-%d %H:%M:%S')

full_text = f"Time: {formatted_time}"
        

ax1.text(-0.01, -0.09, 'SW', fontsize=18, va='top', ha='left', transform=ax1.transAxes)
ax1.text(0.93, -0.09, 'NE', fontsize=18, va='top', ha='left', transform=ax1.transAxes)
ax2.text(-0.01, -0.09, 'SW', fontsize=18, va='top', ha='left', transform=ax2.transAxes)
ax2.text(0.93, -0.09, 'NE', fontsize=18, va='top', ha='left', transform=ax2.transAxes)

time_idx = 3

ax5 = axs[1,0]
        
pt_diff_ctrl_plot = pt_cross_filled_ctrl[time_idx]
dbz_diff_ctrl_plot = dbz_cross_filled_ctrl[time_idx]
ws_projected_ctrl_plot = ws_projected_cross_filled_ctrl[time_idx]
w_ctrl_plot = w_cross_filled_ctrl[time_idx]

cf = ax5.contourf(distances_ctrl, ys, to_np(pt_diff_ctrl_plot),
                    cmap=cmap_pt_cross, levels=levels_pt_cross, norm=norm_pt_cross, extend='both')     

dbz_lines = ax5.contour(distances_ctrl,ys,to_np(dbz_diff_ctrl_plot),          
                     levels=[35,45],              
                     linewidths=1.5,                 
                     colors=['lime','green'],                      
                     linestyles='-'               
                    )

xx, yy = np.meshgrid(distances_ctrl, ys)

skip = (slice(None, None, 1), slice(None, None, 3)) 
Q = ax5.quiver(xx[skip], yy[skip], to_np(ws_projected_ctrl_plot[skip]), to_np(w_ctrl_plot[skip]*n), 
            scale=200,
            width=0.002,        
            headlength=7,       
            headwidth=4,         
            headaxislength=6, 
            alpha=1,          
            linewidth=2
            )
   
ht_fill = ax5.fill_between(distances_ctrl, 0, to_np(ter_line_ctrl/1000),                                
                                    facecolor="saddlebrown",zorder =10)

cp = ax5.contour(distances_ctrl, ys,to_np(pt_diff_ctrl_plot), #绘制等值线图                     
                     levels=[303], #设置w的范围                     
                     linewidths=2, #设置线宽                     
                     colors=['magenta'], #设置等值线颜色                     
                     linestyles='dashed' #设置等值线样式                     
                    )      
# ✅ 自定义 X 轴刻度
x_ticks = [0,10,20,30,40]  # 你想要显示的特定纬度
x_tick_positions = [distances_ctrl[np.argmin(np.abs(np.array(distances_ctrl) - tick))] for tick in x_ticks]  # 找到对应的x坐标位置
x_ticks_sm = [0,10,20,30,40]
x_tick_positions_sm = [distances_sm[np.argmin(np.abs(np.array(distances_sm) - tick))] for tick in x_ticks_sm]  # 找到对应的x坐标位置

ax5.set_xticks(x_tick_positions)
ax5.set_xticklabels(x_ticks, fontsize=20)  # 设置字体大小             
ax5.set_yticks([0, 1,2])
ax5.set_ylim(0.0, 2.1)
ax5.yaxis.set_minor_locator(tick.MultipleLocator(0.2))
ax5.yaxis.set_major_formatter(tick.FormatStrFormatter("%d"))
ax5.tick_params(axis='both', labelsize=20, width=1.5, length=5, direction='out')
ax5.tick_params(axis='y', which='minor', length=3)
#ax5.set_ylabel("Height (km)", fontsize=25, labelpad=10)      
for spine in ax5.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)
ax5.set_ylabel("Height (km)", fontsize=25, labelpad=10)      
ax5.text(0.03, 0.97, '(c) 0220 UTC', transform=ax5.transAxes,
            fontsize=25, ha='left', va='top', fontweight='bold',
            bbox=dict(facecolor='white', alpha=0.8, edgecolor='none', boxstyle='round,pad=0.3'))
       
ax6 = axs[1,1]      
pt_diff_sm_plot = pt_cross_filled_sm[time_idx]        
dbz_diff_sm_plot = dbz_cross_filled_sm[time_idx]        
ws_projected_sm_plot = ws_projected_cross_filled_sm[time_idx]
w_sm_plot = w_cross_filled_sm[time_idx]      

cf = ax6.contourf(distances_sm, ys_sm, to_np(pt_diff_sm_plot),
                    cmap=cmap_pt_cross, levels=levels_pt_cross, norm=norm_pt_cross, extend='both')

dbz_lines = ax6.contour(distances_sm,ys_sm,to_np(dbz_diff_sm_plot),                    
                     levels=[35,45],               
                     linewidths=1.5,                 
                     colors=['lime','green'],                    
                     linestyles='-'                    
                    )

cp = ax6.contour(distances_sm,ys_sm,to_np(pt_diff_sm_plot),                    
                     levels=[303],                 
                     linewidths=2,                  
                     colors=['magenta'],                     
                     linestyles='dashed'                 
                    )

xx, yy = np.meshgrid(distances_sm, ys_sm)

skip = (slice(None, None, 1), slice(None, None, 3))  # x方向步长2，y方向步长1
Q = ax6.quiver(xx[skip], yy[skip], to_np(ws_projected_sm_plot[skip]), to_np(w_sm_plot[skip]*n), 
            scale=200,
            width=0.002,     
            headlength=7,       
            headwidth=4,         
            headaxislength=6,  
            alpha=1,           
            linewidth=2
            )
ax6.set_xticks(x_tick_positions_sm)
ax6.set_xticklabels(x_ticks_sm, fontsize=20)  # 设置字体大小
ax6.set_yticks([0, 1, 2])
ax6.set_ylim(0.0, 2.1)
ax6.yaxis.set_minor_locator(tick.MultipleLocator(0.2))
ax6.yaxis.set_major_formatter(tick.FormatStrFormatter("%d"))
ax6.tick_params(axis='both', labelsize=20, width=1.5, length=5, direction='out')
ax6.tick_params(axis='y', which='minor', length=3) 
ht_fill = ax6.fill_between(distances_sm, 0, to_np(ter_line_sm/1000),                                
                                    facecolor="saddlebrown",zorder =10)


for spine in ax6.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)
        
ax6.text(0.03, 0.97, '(d) 0220 UTC', transform=ax6.transAxes,
            fontsize=25, ha='left', va='top', fontweight='bold',
            bbox=dict(facecolor='white', alpha=0.8, edgecolor='none', boxstyle='round,pad=0.3'))
        
cbar_ax = fig.add_axes([0.155, -0.03, 0.7, 0.02])  # [left, bottom, width, height]
cbar = fig.colorbar(cf, cax=cbar_ax, orientation='horizontal', extend='both')
cbar.set_ticks([301,302,303,304,305,306,307,308,309,310])

cbar.ax.tick_params(labelsize=22, direction='out', length=5, width=1)
for spine in cbar.ax.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1)
    cbar.ax.tick_params(labelsize=20, direction='out', length=5, width=1)

cbar.ax.set_title('Virtual Potential Temperature [K]', fontsize=23, pad=6)

time_value = w_ctrl.Time.values[time_idx]
formatted_time = pd.Timestamp(time_value).strftime('%Y-%m-%d %H:%M:%S')

full_text = f"Time: {formatted_time}"


ax5.text(-0.01, -0.09, 'SW', fontsize=18, va='top', ha='left', transform=ax5.transAxes)
ax5.text(0.93, -0.09, 'NE', fontsize=18, va='top', ha='left', transform=ax5.transAxes)
ax6.text(-0.01, -0.09, 'SW', fontsize=18, va='top', ha='left', transform=ax6.transAxes)
ax6.text(0.93, -0.09, 'NE', fontsize=18, va='top', ha='left', transform=ax6.transAxes)
ax5.set_xlabel("Distance (km)", fontsize=25, labelpad=10)
ax6.set_xlabel("Distance (km)", fontsize=25, labelpad=10)

fig.text(0.25, 0.92, 'CTRL', va='center', rotation='horizontal', fontsize=30, fontweight = 'bold')
fig.text(0.65, 0.92, 'NO_SM', va='center', rotation='horizontal', fontsize=30, fontweight = 'bold')

ax6.quiverkey(Q, 0.85, -0.2, 10, 
             label='10 m/s', 
             labelpos='E', 
             coordinates='axes',
             color='k',
             fontproperties={'size': 15})


plt.savefig('../coldpool_cross_line_0140_0220_new_0107.jpg', dpi=600, bbox_inches="tight")
plt.show()