fig, axes = plt.subplots(1, 3, figsize=(20, 15), sharey=True, subplot_kw={'projection': wrf_proj})
fig.subplots_adjust(wspace=0.1, hspace=0.1)

def plot_map_d02(ax, data, title, is_left=False):
    ax.set_xlim(cartopy_xlim(hgt))
    ax.set_ylim(cartopy_ylim(hgt))
    proj = ccrs.PlateCarree()
    shp_path = '/public/home/acbb7vqhjq/zji/salem_shp/China_shp_lqy/'
    wrf_proj = ccrs.PlateCarree()
    provinces = cfeature.ShapelyFeature(
        Reader(shp_path + 'province.shp').geometries(),
        proj, edgecolor='k',
        facecolor='none'
    )
    ax.add_feature(provinces, linewidth=1.5)
    contour = ax.contourf(to_np(lon_1), to_np(lat_1), to_np(data), transform=ccrs.PlateCarree(),
                          cmap=cmap_ter, levels= levels_ter, norm=norm_ter, extend = 'both')
    
    g1 = ax.gridlines(draw_labels=True, linewidth=1, color='k', alpha=0.8, linestyle='--',
                      x_inline=False, y_inline=False)
    g1.top_labels = False
    g1.right_labels = False
    g1.xformatter = LONGITUDE_FORMATTER
    g1.yformatter = LATITUDE_FORMATTER
    g1.rotate_labels = False
    g1.xlocator = MultipleLocator(2)  
    g1.ylocator = MultipleLocator(2)  
    g1.xlabel_style = {'size': 28} 
    g1.ylabel_style = {'size': 28}  
    if not is_left:
        g1.left_labels = False  
    else:
        g1.left_labels = True   
    
    ax.tick_params(axis='both', labelsize=28, labelcolor='k', direction='out', length=5, width=1.5)
    
    for spine in ax.spines.values():
        spine.set_edgecolor('black') 
        spine.set_linewidth(1.5)     
    ax.set_title(title, fontsize=32, pad = 13, fontweight = 'bold')
    return contour


contourf1 = plot_map_d02(axes[0], hgt, "(a) CTRL", is_left=True)
contourf2 = plot_map_d02(axes[1], hgt_sm, "(b) NO_SM", is_left=False)
contourf3 = plot_map_d02(axes[2], hgt_meso, "(c) NO_MESO", is_left=False)


# 在figure下方添加colorbar
l = 0.28
b = 0.23
w = 0.45
h = 0.03
rect = [l, b, w, h]
cbar_ax = fig.add_axes(rect)
cbar=plt.colorbar(contourf1,cax=cbar_ax,orientation='horizontal')
cbar.ax.set_title('Terrain Height [m]', fontsize=28, pad=8)
custom_ticks = [0, 500, 1000, 1500, 2000]
cbar.set_ticks(custom_ticks)
cbar.ax.tick_params(axis='x', labelsize=28, labelcolor='k', direction='out', length=5, width=1.5)  # 调整标签与刻度线的间距
for spine in cbar.ax.spines.values():
        spine.set_edgecolor('black')  # 设置边框颜色为黑色
        spine.set_linewidth(1.5)      # 设置边框线宽为1.5
plt.savefig("/", dpi=600, bbox_inches="tight")
plt.show()



##response function
# Constants
c1 = 2000  # Given constant value
G1 = 0.3  # Given constant G
c2 = 60000
G2 = 0.4

# Lambda values from 0.1 to 3000 km
lambdas = np.linspace(10, 3000, 1000)  # Avoid division by zero by starting from 0.1 km

# R0 as a function of lambda
R0 = np.exp(-(4 * np.pi**2 * c1) / (lambdas**2))
R0_1 = np.exp(-(4 * np.pi**2 * c2) / (lambdas**2))

# R1 as a function of R0 and G
R_high = 1- R0 * (1 + R0**(G1-1) - R0**G1)
R_low = R0_1 * (1 + R0_1**(G2-1) - R0_1**G2)
R_meso = 1-R_high-R_low

# Plotting R1
fig = plt.figure(figsize=(16, 8))
ax=fig.add_axes([0.09,0.15,0.7,0.6])
plt.plot(lambdas, R_high, label=r"small-scale: high pass",color=(18/255,147/255,146/255), linewidth=4)
plt.plot(lambdas, R_low, label=r"large-scale: low pass",color=(11/255,112/255,183/255), linewidth=4)
plt.plot(lambdas, R_meso, label=r"mesoscale: band pass",color=(205/255,61/255,50/255), linewidth=4)
plt.xlabel(r"Horizontal scale (km)", fontsize=25, labelpad=10)
plt.ylabel(r"Response function", fontsize=25, labelpad=10)
plt.legend(fontsize=20)
plt.grid(True, axis='both', linestyle='--', color='dimgrey', linewidth=1.5, alpha=0.8)
plt.xlim([0, 3000])  # Ensure plot covers the range 0 to 3000 km
plt.ylim([0, 1]) 
plt.xticks([500, 1000, 1500, 2000, 2500, 3000], labels=["500", "1000", "1500", "2000", "2500", "3000"])

ax.tick_params(axis='x', labelsize=22, labelcolor='k', direction='out', length=5, width=1.5, pad =7)
ax.tick_params(axis='y', labelsize=22, labelcolor='k', direction='out', length=5, width=1.5)
ax.xaxis.set_minor_locator(tick.MultipleLocator(100))
ax.xaxis.set_major_formatter(tick.FormatStrFormatter("%d"))
ax.tick_params(axis='x', which='minor', length=3)

for spine in ax.spines.values():
        spine.set_edgecolor('black')  # 设置边框颜色为黑色
        spine.set_linewidth(1.5)      # 设置边框线宽为1.5
fig.text(0.05, 0.8,"(d)", fontsize=32, fontweight = 'bold')
plt.savefig("/", dpi=600, bbox_inches="tight")
plt.show()