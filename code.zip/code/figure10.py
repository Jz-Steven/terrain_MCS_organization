def plot_rain_distribution(ax, lons, lats, wspd_data, u, v, mdbz,terrain,
                           levels, cmap, norm, provinces, wrf_proj, title, is_left=False, is_bottom=False):
    

    im = ax.contourf(
        to_np(lons), to_np(lats), to_np(wspd_data),
        levels=levels, cmap=cmap, norm=norm,
        transform=ccrs.PlateCarree(), alpha=1
    )

    mdbz = ax.contour(
        to_np(lons), to_np(lats), to_np(mdbz),levels=[40],colors=['crimson'],
        linestyles=['solid'], linewidths=2,
        transform=ccrs.PlateCarree(), alpha=1
    )

    ter = ax.contour(
        to_np(lons), to_np(lats), to_np(terrain),levels=[300],colors=['saddlebrown'],
        linestyles=['solid'], linewidths=1.5,
        transform=ccrs.PlateCarree(), alpha=1
    )

    n = 30
    ax.barbs(to_np(lons[::n,::n]), to_np(lats[::n,::n]),
             to_np(u[6,1][::n,::n]), to_np(v[6,1][::n,::n]),
             linewidth=1,flagcolor='k',length=6, pivot='tip', 
             barb_increments=dict(half=2, full=4, flag=20), transform=ccrs.PlateCarree())

    ax.add_feature(provinces, edgecolor='dimgrey', linewidth=1)
    ax.set_extent([116.3,119,23.1,25.3], crs=ccrs.PlateCarree())
    gl = ax.gridlines(color="black", linestyle="dotted", draw_labels=True, x_inline=False, y_inline=False)
    gl.top_labels = False
    gl.right_labels = False
    gl.rotate_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    gl.xlocator = FixedLocator(np.arange(116.5, 120, 1))  
    gl.ylocator = MultipleLocator(1)
    gl.xlabel_style = {'size': 25}
    gl.ylabel_style = {'size': 25}
    if not is_left:
        gl.left_labels = False  
    else:
        gl.left_labels = True  
        
    if not is_bottom:
        gl.bottom_labels = False 
    else:
        gl.bottom_labels = True 
        
    ax.tick_params(axis='both', labelsize=25, labelcolor='k', direction='out', length=5, width=1.5)

    for spine in ax.spines.values():
            spine.set_edgecolor('black') 
            spine.set_linewidth(1.5)    

    ax.text(0.04, 0.965, title, fontsize=30, fontweight = 'bold', transform=ax.transAxes, va='top', ha='left',
            bbox=dict(facecolor='white', alpha=0.7, edgecolor='white', boxstyle='round,pad=0.3'))
    
    return im


def create_combined_plot():
  
    fig = plt.figure(figsize=(15, 15))

    gs = gridspec.GridSpec(2, 2, height_ratios=[1.2, 1], hspace=0.1, wspace=0.1)
    wspd_data_1 = wspd_ctrl[6,1]
    wspd_data_2 = wspd_sm[6,1]
    shp_path = '/public/home/acbb7vqhjq/zji/salem_shp/China_shp_lqy/'
    provinces = cfeature.ShapelyFeature(
        Reader(shp_path + 'province.shp').geometries(),
        ccrs.PlateCarree(), edgecolor='k', facecolor='none'
    )
    

    ax1 = fig.add_subplot(gs[0, 0], projection=wrf_proj)
    im1= plot_rain_distribution(
        ax1, lons, lats, wspd_ctrl[18,1], u_ctrl, v_ctrl, mdbz_ctrl,terrain_ctrl,
        levels_wspd, cmap_wspd, norm_wspd, provinces, wrf_proj, "(a) CTRL",
        is_left=True, is_bottom=True  
    )
    
    ax2 = fig.add_subplot(gs[0, 1], projection=wrf_proj)
    im2 = plot_rain_distribution(
        ax2, lons, lats, wspd_sm[18,1], u_sm, v_sm, mdbz_sm,terrain_sm,
        levels_wspd, cmap_wspd, norm_wspd, provinces, wrf_proj, "(b) NO_SM",
        is_left=False, is_bottom=True  
    )

    lon_min, lon_max = 117.3, 117.4
    lat_min, lat_max = 23.2, 24.3
    rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
    rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
    ax1.plot(rect_lons, rect_lats, color='magenta', linewidth=2, transform=ccrs.PlateCarree(), linestyle='-', alpha = 1)
    ax2.plot(rect_lons, rect_lats, color='magenta', linewidth=2, transform=ccrs.PlateCarree(), linestyle='-', alpha = 1)
    
    ax3 = fig.add_subplot(gs[1, 0])
    wspd1 = ax3.contourf(
        to_np(lat_plot), Time_correct[0:32], 
        to_np(wspd_west_east_mean_ctrl[0:32,1]),
        levels=levels_wspd, cmap=cmap_wspd, norm=norm_wspd, extend='max'
    )
    
    div = ax3.contour(
    to_np(lat_plot),                  
    Time_correct[0:32],         
    to_np(div_west_east_mean_ctrl[0:32]*10**5),
    levels=[-50],colors=['k'],
    linestyles=['solid'], linewidths=1.2,
    alpha=1
    )
 
    ax3.set_xlabel("Latitude(°N)", fontsize=28, labelpad=10)
    ax3.set_ylabel("Time on May 7(UTC)", fontsize=28, labelpad=15)
    ax3.set_xticks(chosen)
    ax3.set_xticklabels([f"{lat:.1f}" for lat in chosen], fontsize=25)
    ax3.yaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    ax3.tick_params(axis='both', labelsize=25, width=1.5, length=5)
    ax3.grid(True, linestyle='--', color='dimgrey', linewidth=1.5, alpha=1)
    ax3.set_yticks(Time_correct[0:32][::6]) 
    ax3.yaxis.set_major_formatter(mdates.DateFormatter('%H%M'))
    ax3.tick_params(axis='x', labelsize=25, labelcolor='k', direction='out', length=5, width=1.5)
    ax3.tick_params(axis='y', labelsize=25, labelcolor='k', direction='out', length=5, width=1.5)
    ax3.grid(True, axis='x', linestyle='--', color='dimgrey', linewidth=1.5, alpha=1)
    ax3.grid(True, axis='y', linestyle='--', color='dimgrey', linewidth=1.5, alpha=1)


    ax3.text(0.03, 0.9, '(c) CTRL', transform=ax3.transAxes,
            fontsize=30, weight='bold', bbox=dict(facecolor='white', alpha=0.7, edgecolor='white', boxstyle='round,pad=0.3'))
    
    ax4 = fig.add_subplot(gs[1, 1], sharey=ax3)
    wspd2 = ax4.contourf(
        to_np(lat_plot), Time_correct[0:32],
        to_np(wspd_west_east_mean_sm[0:32,1]),
        levels=levels_wspd, cmap=cmap_wspd, norm=norm_wspd, extend='max'
    )
    div = ax4.contour(
    to_np(lat_plot),                   
    Time_correct[0:32],           
    to_np(div_west_east_mean_sm[0:32]*10**5),
    levels=[-50],colors=['k'],
    linestyles=['solid'], linewidths=1.2,
    alpha=1
    )

    ax4.set_xlabel("Latitude(°N)", fontsize=28, labelpad=10)
    ax4.set_xticks(chosen)
    ax4.set_xticklabels([f"{lat:.1f}" for lat in chosen], fontsize=25)
    ax4.tick_params(axis='both', labelsize=25, width=1.5, length=5)
    ax4.grid(True, linestyle='--', color='dimgrey', linewidth=1.5, alpha=1)

    ax4.text(0.03, 0.9, '(d) NO_SM', transform=ax4.transAxes,
            fontsize=30, weight='bold', bbox=dict(facecolor='white', alpha=0.7, edgecolor='white', boxstyle='round,pad=0.3'))
    ax4.yaxis.set_tick_params(labelleft=False)
 
    cbar_ax1 = fig.add_axes([0.22, -0.01, 0.6, 0.015]) 
    cbar1 = fig.colorbar(im1, cax=cbar_ax1, orientation='horizontal')
    cbar1.ax.set_title('Wind Speed [m·s$^{-1}$]', fontsize=23, pad=6)
    cbar1.set_ticks([0,2,4,6,8,10,12,14,16,18,20])
    cbar1.ax.tick_params(labelsize=23, width=1, length=5)
    
    plt.savefig('wspd_combined_plot_0131.jpg', dpi=600, bbox_inches="tight")
    plt.show()

# 执行函数
create_combined_plot()